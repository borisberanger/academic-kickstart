library(ExtremalDep)

# Load dataset(s)
data(MilanPollution)

pollutants <- colnames(Milan.winter)[c(2,3,5,6)]
pol.index <- match(pollutants, colnames(Milan.winter))
covariates <- colnames(Milan.winter)[8]
cov.index <- which(colnames(Milan.winter) == covariates)
Covariates <- c("Max Temperature")

covar <- cbind(rep(1,nrow(Milan.winter)), Milan.winter[,cov.index], Milan.winter[,cov.index]^2 )

P <- c(1/600, 1/1200, 1/2400)  # Vector of probabilities for extreme quantiles
prob <- c(0.9, 0.9) # To use to evaluate thresholds

load(file=paste("Univariate_Winter_Data_cov",covariates, ".Rdata",sep="")) # Load results from univariate analysis

pairs <- rbind(c("NO2", "SO2"), c("NO2", "PM10"), c("SO2", "PM10"))

for(p in 1:nrow(pairs)){
  
  pols <- pairs[p,]
  cat("\n Analysis of the pairs:",pols[1], " and ",pols[2],"\n")
  pols.index <- match(pols, colnames(Milan.winter))
  
  mcmc1 <- mcmc.winter[[paste("mcmc.winter",pols[1],"_prob",prob[1],sep="")]]
  mcmc2 <- mcmc.winter[[paste("mcmc.winter",pols[2],"_prob",prob[2],sep="")]]
  
  par10 <- apply(mcmc1$post_sample[mcmc1$straight.reject==0,],2,mean)
  par20 <- apply(mcmc2$post_sample[mcmc2$straight.reject==0,],2,mean)
  sig10 <- tail(mcmc1$sig.vec,1)
  sig20 <- tail(mcmc2$sig.vec,1)  
  prior.k <- "nbinom" # Prior distribution for polynomial degree
  k0 <- 5 # Degree of the polynomial
  prior.pm <- "unif" # Prior distribution for the point masses
  pm0 <- list(p0=0, p1=0)
  if(all(pols == c("NO2", "SO2"))){ hyperparam <- list(mu.nbinom = 6, var.nbinom = 8, a.unif = 0, b.unif = 0.2)} # Vector of hyperparameters for prior distribution
  if(all(pols == c("NO2", "PM10")) || all(pols == c("SO2", "PM10"))){ hyperparam <- list(mu.nbinom = 6, var.nbinom = 8, a.unif = 0, b.unif = 0.1)}
  
  data <- Milan.winter[complete.cases(cbind(Milan.winter[,pols.index],covar)),pols.index]
  Cov <- as.matrix(covar[complete.cases(cbind(Milan.winter[,pols.index],covar)),])
  
  QatCov <-  rbind(Cov[which(Cov[,2] == quantile(Cov[,2], probs=0, type=3) )[1],-1],
                   Cov[which(Cov[,2] == quantile(Cov[,2], probs=0.5, type=3) )[1],-1],
                   Cov[which(Cov[,2] == quantile(Cov[,2], probs=1, type=3) )[1],-1])
  
  assign(paste("Q.",pols[1],".",pols[2],sep=""), 
         ExtQset(data=as.matrix(data), P=P, cov1=Cov, cov2=Cov, QatCov1=QatCov, QatCov2=QatCov, mar=FALSE, 
                 par10=par10, par20=par20, sig10=sig10, sig20=sig20, k0 = k0, pm0=pm0, 
                 prior.k = prior.k, prior.pm = prior.pm, hyperparam = hyperparam, nsim=50000))
  
  filename <- paste("Milan_Winter_",pols[1],"_",pols[2],"_",1/P[1],"_",1/P[2],"_",1/P[3],".RData",sep="")
  save(list=c(paste("Q.",pols[1],".",pols[2],sep=""),"k0", "P", "hyperparam"), file=filename)
  
  ### Graphical Representations
  
  W <- seq(0.00001, .99999, length=100)
  Q <- get(paste("Q.",pols[1],".",pols[2],sep=""))
  
  rbPal <- colorRampPalette(c('blue','red'))
  Colors <- rbPal(10)
  data.col <- Colors[as.numeric(cut(Cov[,2],breaks = 10))]
  
  ## 1st Graph: Dependence
  
  par(mfrow=c(1,3), mar=c(3, 3, 0.5, 0.2), mgp=c(2,.8,0))
  
  # Density of the exponent function
  if(all(pols == c("NO2", "SO2"))){ylim.e <- c(0.2,160)}
  if(all(pols == c("NO2", "PM10"))){ylim.e <- c(0.2,200)}
  if(all(pols == c("SO2", "PM10"))){ylim.e <- c(0.2,3500)}
  plot(W, Q$ghat[2,],col="gray0", lwd=2, type="l", ylim=ylim.e, xlab="w", ylab=expression(1/q[symbol("\052")](w)))
  polygon(c(W, rev(W)), c(Q$ghat[3,], rev(Q$ghat[1,])), col="gray")
  lines(W, Q$ghat[2,],col="gray0", lwd=2, type="l", lty=3)
  
  # Basic set
  if(all(pols == c("NO2", "SO2"))){xlim.b <- ylim.b <- c(0,150)}
  if(all(pols == c("NO2", "PM10"))){xlim.b <- ylim.b <- c(0,170)}
  if(all(pols == c("SO2", "PM10"))){xlim.b <- ylim.b <- c(0,3200)}
  plot(Q$Shat[,,2], type="l", col="gray0", lwd=2, xlab=pols[1], ylab=pols[2], xlim=xlim.b, ylim=ylim.b)
  polygon(c(Q$Shat[,1,3], rev(Q$Shat[,1,1])), c(Q$Shat[,2,3], rev(Q$Shat[,2,1])), col="gray")
  points(Q$Shat[,,2], type="l", col="gray0", lwd=2, lty=3)
  
  # Data
  if(all(pols == c("NO2", "SO2"))){xlim.d <- ylim.d <- c(0,350)}
  if(all(pols == c("NO2", "PM10"))){xlim.d <- ylim.d <- c(0,400)}
  if(all(pols == c("SO2", "PM10"))){xlim.d <- ylim.d <- c(0,320)}
  plot(data, pch=19, xlab=pols[1], ylab=pols[2], xlim=xlim.d, ylim=ylim.d, col=data.col)
  
  plotname.dep <- sub(".RData", "_dep.pdf", filename)
  dev.copy2pdf(file=plotname.dep, height=2, width=6)
  
  ## 2nd graph: Quantile regions
  
  # Quantile Regions
  
  if(all(pols == c("NO2", "SO2"))){xlim.q <- ylim.q <- c(0,800)}
  if(all(pols == c("NO2", "PM10"))){xlim.q <- ylim.q <- c(0,700)}
  if(all(pols == c("SO2", "PM10"))){xlim.q <- ylim.q <- c(0,410)}
  
  par(mfrow=c(1,3), mar=c(3, 3, 0.5, 0.2), mgp=c(2,.8,0))
  
  for(i in 1:length(P)){
    
    plot(data, xlim=xlim.q, ylim=ylim.q, type="n", pch=19, xlab=pols[1], ylab=pols[2])
    
    for(j in 1:(ncol(QatCov)+1)){
      
      tmp <- Q[[paste("Qset_P",i,"_CovNum_",j,sep="")]]
      Vcol <- quantile(1:10,probs=(j-1)/2,type=3)
      polygon(c(tmp[,1,3], rev(tmp[,1,1])), c(tmp[,2,3], rev(tmp[,2,1])), col=adjustcolor( Colors[Vcol], alpha.f = 0.6), border=NA)
      lines(tmp[,,2], lty=1, col=adjustcolor( Colors[Vcol], alpha.f = 1), lwd=2)
      
    }
    
  }
  
  plotname.quant <- sub(".RData", "_quant.pdf", filename)
  dev.copy2pdf(file=plotname.quant, height=2, width=6)
  
}

