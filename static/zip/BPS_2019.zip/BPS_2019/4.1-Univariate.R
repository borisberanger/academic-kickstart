library(extraDistr)
library(mvtnorm) # for MVN proposals
library(ExtremalDep)

distributions <- c("FRE", "HT", "IG")

for(distribution in distributions){
  
  cat("\n Distribution:", distribution, "\n")
  set.seed(999)
  n <- 1500
  loc <- 3
  scale <- 1
  shape1 <- 1/3
  shape2 <- 0.5
  prob <- 0.9
  cov <- as.matrix(rep(1,n))

  if(distribution=="FRE"){ # MDA(FRE), Tail index "xi"
    # data <- rgev(n = n, mu = loc, sigma = scale, xi = shape1)
    data <- rfrechet(n = n, mu = loc, sigma = scale, lambda =shape1)
    pars <- c(loc, scale, shape1)
    pars.name <- paste("loc", loc*10, "_scale", scale*10, "_shape", shape1*10, sep="")
  }
  if(distribution=="HT"){ # MDA(FRE), Tail index "1/nu"
    data <- rht(n = n, nu=shape1, sigma = scale)
    pars <- c(shape1, scale)
    pars.name <- paste("Dof", shape1*10,"_sigma", scale, sep="")  
  } 
  if(distribution=="IG"){ # MDA(FRE), Tail index "1/alpha"
    data <- rinvgamma(n = n, alpha = shape2, beta = scale)  
    pars <- c(scale, shape2)
    pars.name <- paste("scale", scale*10, "_shape", shape2*10, sep="")
  }

  ### Required for Bayesian Estimation
  nsim <- 5e+4
  param0 <- c(1, 2, 1)
  P <-c(1/750, 1/1500, 1/3000)
  U <- quantile(data, probs=prob, type=3)
  sig0 <- 1
  
  ### Estimation
  
  mcmc.name <- paste("mcmc",distribution,"_n", n, "_prob", prob, "_", pars.name,sep="")
  filename <- paste(distribution,"_n", n, "_prob", prob, "_", pars.name,"_real.RData",sep="")
  diag.name <- sub("_real.RData", "_diagnostics.pdf", filename)
  pdf(diag.name, onefile=TRUE)
  par(mar=c(4.2,4.6,0.3,0.1))
  assign(mcmc.name, UniExtQ(data=data, P=P, U=U, cov=cov, param0=param0, sig0=sig0, nsim=nsim))
  dev.off()
  save(list= mcmc.name, distribution, nsim, param0, file=filename)
  
  ### Illustration
  
  if(distribution=="FRE" || distribution=="HT"){ti <- 1/shape1}
  if(distribution=="IG"){ti <- 1/shape2}

  mcmc <- get(mcmc.name)
  Kern <- density(mcmc$post_sample[,ncol(cov)+2]) # Kernel density estimation of the tail index

  plotname <- sub(".RData", "grey_scale2.pdf", filename)
  pdf(plotname, onefile=TRUE)
  par(mar=c(4.2,4.6,0.3,0.1))
  Hist <- hist(mcmc$post_sample[,ncol(cov)+2], prob=TRUE, col="lightgrey", ylim=range(Kern$y), main="", xlab="Tail Index", cex.lab=1.8, cex.axis=1.8, lwd=2)
  ti_ic <- quantile(mcmc$post_sample[,ncol(cov)+2], probs=c(0.025, 0.975))
  points(x=ti_ic, y=c(0,0), pch=4, lwd=4)
  lines(Kern, lwd = 2, col = "dimgrey")
  abline(v=ti, lwd=2)
  abline(v=mean(mcmc$post_sample[,ncol(cov)+2]), lwd=2, lty=2) # Posterior sample of the tail index
  
  #### Check the ability to estimate quantile regions
  if(distribution=="FRE"){
    Q <- qfrechet(p = P, mu = loc, sigma = scale, lambda = shape1, lower.tail=FALSE)
  } 
  if(distribution=="HT"){
    Q <- qht(p = P, nu = shape1, sigma = scale, lower.tail=FALSE)
  } 
  if(distribution=="IG"){
    Q <- qinvgamma(p = P, alpha = shape2, beta = scale, lower.tail=FALSE)  
  }

  ci <- apply(log(mcmc$Q.est),2,function(x) quantile(x, probs=c(0.025, 0.975)))
  for(i in 1:length(P)){
    cat("\n Confidence interval extreme quantile with Probability ", P[i]," : (", ci[1,i],",",ci[2,i],") \n")    
  }
  
  Kern.est <- apply(log(mcmc$Q.est),2,density)
  
  R <- range(log(c(Q,mcmc$Q.est,data)))
  Xlim <- c(log(quantile(data,0.95)), R[2])
  Ylim <- c(0, max(Kern.est[[1]]$y, Kern.est[[2]]$y, Kern.est[[3]]$y))
  
  plot(log(data), rep(0,n), pch=16, main="", xlim=Xlim, ylim=Ylim, xlab=expression(log(x)), ylab="Density", cex.lab=1.8, cex.axis=1.8, lwd=2)
  polygon(Kern.est[[1]], col= rgb(211,211,211, 0.8*255, maxColorValue = 255), border=rgb(211,211,211, 255, maxColorValue = 255), lwd=4)
  polygon(Kern.est[[2]], col= rgb(169,169,169, 0.8*255, maxColorValue = 255), border=rgb(169,169,169, maxColorValue = 255), lwd=4)
  polygon(Kern.est[[3]], col= rgb(105,105,105, 0.8*255, maxColorValue = 255), border=rgb(105,105,105, maxColorValue = 255), lwd=4)
  points(log(data), rep(0,n), pch=16, lwd=2)
  abline(v=log(Q), lwd=2, lty=1)
  for(j in 1:length(P)){abline(v=mean(log(mcmc$Q.est[,j])), lwd=2, lty=2)}
  
  # Frequentist approach
  #q <- UniExtQ(data=data, method="frequentist", P=P, param0=param0, control = list(maxit = 5e+5, trace = 2))
  #abline(v=log(q$Q.est), lwd=2, lty=3)
  
  dev.off()
}  

