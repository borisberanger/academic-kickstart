library(ExtremalDep)
library(rasterVis)

# Load dataset(s)
data(MilanPollution)

pollutants <- colnames(Milan.winter)[c(2,3,5,6)]
pol.index <- match(pollutants, colnames(Milan.winter))
covariates <- colnames(Milan.winter)[8]
cov.index <- which(colnames(Milan.winter) == covariates)
Covariates <- c("Max Temperature")

P <- c(1/600, 1/1200, 1/2400)  # Vector of probabilities for extreme quantiles
prob <- c(0.9) # To use to evaluate thresholds

###
### Marginal Analysis
###

### Plot Pollutants vs Covariates (daily maximum temperature)

pdf(file="Pollutants_vs_MaxTemp.pdf", height=5, width=6.5)
par(mar=c(4.2,4.6,0.3,0.1))

for(j in 1:length(pollutants)){

    tmp <- Milan.winter[,j+1]
    Cov <- Milan.winter[,cov.index]
    non.na <- which( rowSums(!is.na(  cbind(tmp, Cov)))==2 )
    tmp <- tmp[non.na]
    tmp.cov <- as.matrix(Cov[non.na])

    plot(tmp.cov, tmp, pch=16, ylab=pollutants[j], xlab=Covariates, cex.lab=1.7)
    above <- (tmp > quantile(tmp, probs=prob, type=3))
    points(tmp.cov[above], tmp[above], col=4, pch=16)

}

dev.off()

### Estimation

mcmc.winter <- list()

# Matrix of covariates
covar <- cbind(rep(1,nrow(Milan.winter)), Milan.winter[,cov.index], Milan.winter[,cov.index]^2 )
colnames(covar) <- c("Intercept", covariates, covariates)

# Starting values
param0 <- c(60, rep(0,ncol(covar)-1), 10, 1)
sig0 <- 1
nsim <- 3e+5

for(i in 1:length(pol.index)){  
  
  cat("Pollutant:", pollutants[i], "\n")

  # Remove NAs from data
  tmp <- Milan.winter[,pol.index[i]]
  non.na <- which( rowSums(!is.na(  cbind(tmp, covar)))==(ncol(covar)+1))
  tmp <- tmp[non.na]
  tmp.cov <- as.matrix(covar[non.na,])
  
  # Value of the covariates at which the extreme quantiles are evaluated
  nZ <- 100  
  Z <- seq(from=min(tmp.cov[,2]), to=max(tmp.cov[,2]), length=nZ)
  QatCov <- cbind(Z,Z^2)    

  mcmc.name <- paste("mcmc.winter",pollutants[i], "_prob", prob,sep="")
  Time <- system.time(
    mcmc.winter[[mcmc.name]] <- UniExtQ(data = tmp, P = P, U = quantile(tmp,probs=prob, type=3), cov = tmp.cov, QatCov = QatCov, param0 = param0, sig0 = sig0, nsim = nsim)
  )
  save(mcmc.winter, nsim, param0, time=Time, file=paste("Univariate_Winter_Data_cov",covariates, ".Rdata",sep=""))
  cat("\n Time (sec) taken: ", Time[3], "\n" )
  
  # Illustration
  R <- range(mcmc.winter[[mcmc.name]]$Q.est)
  
  if(pollutants[i]=="NO2"){Rmax <- 2200}
  if(pollutants[i]=="NO"){Rmax <- 11000}
  if(pollutants[i]=="SO2"){Rmax <- 800}
  if(pollutants[i]=="PM10"){Rmax <- 800}
  
  Kern_Q1.est <- apply(mcmc.winter[[mcmc.name]]$Q.est[[1]],2, function(x) density(x, from=R[1], to=Rmax)$y)
  Kern_Q2.est <- apply(mcmc.winter[[mcmc.name]]$Q.est[[2]],2, function(x) density(x, from=R[1], to=Rmax)$y)
  Kern_Q3.est <- apply(mcmc.winter[[mcmc.name]]$Q.est[[3]],2, function(x) density(x, from=R[1], to=Rmax)$y)
  
  D1 <- cbind(expand.grid(Z, seq(from=R[1],to=Rmax, length=512)), as.vector(t(Kern_Q1.est)) )
  D2 <- cbind(expand.grid(Z, seq(from=R[1],to=Rmax, length=512)), as.vector(t(Kern_Q2.est)) )
  D3 <- cbind(expand.grid(Z, seq(from=R[1],to=Rmax, length=512)), as.vector(t(Kern_Q3.est)) )
  colnames(D1) <- colnames(D2) <- colnames(D3) <- c("x","y","z")
  
  Xlim <- range(tmp.cov[,2]); 
  Ylab <-bquote(.(pollutants[i]) );
  
  pdf(file=paste("QuantilePlot_winter_",pollutants[i],"_cov",covariates,"_prob", prob, ".pdf",sep=""), height=5, width=6)
  print(levelplot(z~x*y, data=D1, xlim=Xlim, ylim=c(R[1],Rmax), par.settings = rasterVis::magmaTheme(),xlab=list(Covariates, cex=1.7), ylab=list(Ylab, cex=1.7), scales=list(x=list(cex=1.1), y=list(cex=1) ))) 
  print(levelplot(z~x*y, data=D2, xlim=Xlim, ylim=c(R[1],Rmax), par.settings = rasterVis::magmaTheme(),xlab=list(Covariates, cex=1.7), ylab=list(Ylab, cex=1.7), scales=list(x=list(cex=1.1), y=list(cex=1) )))
  print(levelplot(z~x*y, data=D3, xlim=Xlim, ylim=c(R[1],Rmax), par.settings = rasterVis::magmaTheme(),xlab=list(Covariates, cex=1.7), ylab=list(Ylab, cex=1.7), scales=list(x=list(cex=1.1), y=list(cex=1) ))) 
  dev.off()
  
}
  

  