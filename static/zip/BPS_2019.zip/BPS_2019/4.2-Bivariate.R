library(ExtremalDep)
library(mvtnorm)
library(tmvtnorm)

distributions <- c("Cauchy", "Asymmetric", "Clover", "HT")
distribution <- distributions[4]

par10 <- par20 <- c(1,2,1) # Initial marginal parameter values
sig10 <- sig20 <- 1 # Initial scale values in MVN proposal
prior.k <- "nbinom" # Prior distribution for polynomial degree
k0 <- 5 # Degree of the polynomial
prior.pm <- "unif" # Prior distribution for the point masses
pm0 <- list(p0=0, p1=0)
hyperparam <- list(mu.nbinom = 3.2, var.nbinom = 4.48, a.unif = 0, b.unif = 0.1) # Vector of hyperparameters for prior distribution

###
### Data simulation
###

n <- 1500 # Sample size
P <- c(1/750, 1/1500, 1/3000) # Vector of probabilities for extreme quantiles
prob <- c(0.9, 0.9) # To use to evaluate thresholds

if(distribution=="Cauchy"){
  
  # Dependence structure;
  rho <- 0
  sigma <- matrix(c(1,rho,rho,1), ncol=2)
  df <- 1
  
  # Compute quantiles for the Cauchy:
  ell1 <- ellipse(prob=1-P[1], pos=TRUE)
  ell2 <- ellipse(prob=1-P[2], pos=TRUE)
  ell3 <- ellipse(prob=1-P[3], pos=TRUE)
  
  realx1 <- ell1[,1]; realy1 <- ell1[,2]
  realx2 <- ell2[,1]; realy2 <- ell2[,2]
  realx3 <- ell3[,1]; realy3 <- ell3[,2]  
  
  # Data simulation (Cauchy)
  set.seed(999)
  data <- rmvt(5*n, sigma=sigma, df=df)
  data <- data[data[,1]>0 & data[,2]>0, ]
  data <- data[1:n, ]
  
}

if(distribution=="Asymmetric"){
  
  ## real quantile regions
  cs1 <- 4e6
  cs2 <- 2e7
  cs3 <- 9e7  ## num. int. in Matlab
  
  real1 <- function(x){(cs1-x^3)^(1/4)} # EdH
  real2 <- function(x){(cs2-x^3)^(1/4)} # EdH (c from Matlab, for_EdH_simulations folder)
  real3 <- function(x){(cs3-x^3)^(1/4)} # EdH
  
  realx1 <- seq(0, cs1^(1/3), by = cs1^(1/3)/100)
  realx2 <- seq(0, cs2^(1/3), by = cs2^(1/3)/100)
  realx3 <- seq(0, cs3^(1/3), by = cs3^(1/3)/100)
  
  realy1 <- real1(realx1)
  realy2 <- real2(realx2)
  realy3 <- real3(realx3)  
  
  # Data simulation (Asymmetric)
  set.seed(1) # set.seed(14342)
  data <- ExtremalDep:::simData(n)$rez
  
}

if(distribution=="Clover"){
  
  ## real quantile regions
  lg <- 1000
  
  cc1 <- 2.966e-10
  cc2 <- 3.13e-11
  cc3 <- 3.28e-12
  
  clover0 <- function(x){(16/5/pi)*(((x[1]^2+x[2]^2)^2)-(3*(x[1]*x[2])^2))/((1+x[1]^2+x[2]^2)^(3/2))/((x[1]^2+x[2]^2)^2)}
  cloverI <- function(x){(4/5)*((x[2]+1)^(-1/5))*clover0(c(x[1],(x[2]+1)^(4/5)-1 ))}
  
  realx1 <- seq(0.1,1400.574,1400.474/lg)
  realx2 <- seq(0.1,2963.798,2963.698/lg)
  realx3 <- seq(0.1,6286.449,6286.349/lg)
  
  realy1 <- rep(0,lg+1)
  realy2 <- rep(0,lg+1)
  realy3 <- rep(0,lg+1)
  
  for(i in 1:(lg+1)){
    fc1 <- function(x){(cloverI(c(realx1[i],x))-cc1)^2}
    fc2 <- function(x){(cloverI(c(realx2[i],x))-cc2)^2}
    fc3 <- function(x){(cloverI(c(realx3[i],x))-cc3)^2}
    
    realy1[i] <- optimize(fc1,c(0,1e5))$minimum
    realy2[i] <- optimize(fc2,c(0,2e5))$minimum
    realy3[i] <- optimize(fc3,c(0,3e5))$minimum
  }
  
  # Data simulation (Clover)
  set.seed(14342)
  data <- ExtremalDep:::simulationsClover(n)
  data <- cbind(data[,1], (data[,2]+1)^(5/4)-1)
  
}

if(distribution=="HT"){
  
  # Dependence structure;
  rho <- 0.5
  sigma <- matrix(c(1,rho,rho,1), ncol=2)
  df <- 2
  
  # Compute quantiles for the HT:
  ell1 <- ellipse(prob=1-P[1], sigma=sigma, df=df, pos=TRUE)
  ell2 <- ellipse(prob=1-P[2], sigma=sigma, df=df, pos=TRUE)
  ell3 <- ellipse(prob=1-P[3], sigma=sigma, df=df, pos=TRUE)
  
  realx1 <- ell1[,1]; realy1 <- ell1[,2]
  realx2 <- ell2[,1]; realy2 <- ell2[,2]
  realx3 <- ell3[,1]; realy3 <- ell3[,2]  
  
  # Data simulation (Bivariate-t on positive quadrant)
  set.seed(101) #set.seed(14342)
  data <- rtmvt(n=n, sigma=sigma, lower=rep(0,2), df=df)
}

# Threshold
U <- c(quantile(data[,1], probs = prob[1], type=3), quantile(data[,2], probs = prob[2], type=3))

###
### Analysis joint
###

Q <- ExtQset(data=data, P=P, U=U, par10=par10, par20=par20, sig10=sig10, sig20=sig20, pm0=pm0,
             k0=k0, prior.k=prior.k, prior.pm=prior.pm, hyperparam=hyperparam, nsim=50000)

Q.EDhK <- ExtQset(data=data, P=P, method="EDhK", lo=50, up=300)

save(Q,Q.EDhK, file=paste("CensQsets_",distribution,"_k0_",k0,".RData",sep=""))

# define grid
w <- seq(0.00001, .99999, length=100)

# Compute the true g function
if(distribution=="Cauchy"){
  gfun <- ((w^2+(1-w)^2)^(-3/2))^(1/3)
}
if(distribution=="Asymmetric"){
  c <- 0.581; c1 <- 0.589; c2 <- 0.593;
  gfun <- (c * c1 * c2 / ( c1^3*w^(12/5) + c2^4*(1-w)^(12/5) ))^(5/12) 
}
if(distribution=="Clover"){
  c <- 0.208
  gfun <- (32/5 * c * (w^4 - w^2*(1-w)^2 + (1-w)^4) / ((w^2 + (1-w)^2)^(7/2) * (1-w)^(1/4) )  )^(4/13)
}
if(distribution=="HT"){
  sq <- sqrt((df+1)/(1-rho^2))  
  gfun <- ( df / w^(1+2/df) / (1 - pt(-rho*sq, df=df+1)) * sq * dt(sq*( ((1-w)/w)^(1/df) - rho), df=df+1) )^(df/(2+df))
  # gfun <- ( 2* df / w^(1+2/df) * sq * dt(sq*( ((1-w)/w)^(1/df) - rho), df=df+1) )^(df/(2+df))
}

xT <- gfun*w
yT <- gfun*(1-w)

###################################################################################################
# Graphical representation

par(mfrow=c(2,3), mar=c(3, 3, 0.5, 0.2), mgp=c(2,.8,0))
#
# Plot 1: Density of Exponent measure
#
if(distribution=="Cauchy"){ ylim.pl1 <- c(0,1.7)}
if(distribution=="Asymmetric"){ylim.pl1 <- c(0,2)}
if(distribution=="HT"){ylim.pl1 <- c(0,2.8)}
if(distribution=="Clover"){ylim.pl1 <- c(0,2.2)}
plot(w, gfun, type="l", xlab="w", ylab=expression(1/q[symbol("\052")](w)), ylim=ylim.pl1)
polygon(c(w, rev(w)), c(Q$ghat[3,], rev(Q$ghat[1,])), col="gray")
lines(w, Q$ghat[2,],col="gray0", lwd=2, lty=3)
lines(w, gfun, lwd=2)
#
# Plot 2: Basic-set S
#
if(distribution=="Cauchy"){xlim.pl2 <-c(0,1.5); ylim.pl2 <- c(0,1.5)}
if(distribution=="Asymmetric"){xlim.pl2 <-c(0,1.5); ylim.pl2 <- c(0,1.5)}
if(distribution=="HT"){xlim.pl2 <-c(0,2); ylim.pl2 <- c(0,2)}
if(distribution=="Clover"){xlim.pl2 <-c(0,1.8); ylim.pl2 <- c(0,1.8)}
plot(xT,yT, pch=19, col=1, type="l", xlim=xlim.pl2, ylim=ylim.pl2, xlab=expression(x[1]), ylab=expression(x[2]))
polygon(c(Q$Shat[,1,3], rev(Q$Shat[,1,1])), c(Q$Shat[,2,3], rev(Q$Shat[,2,1])), col="gray")
points(Q$Shat[,,2], type="l", col="gray0", lwd=2, lty=3)
lines(xT,yT,lwd=2)
#
# Plot 3: Data + quantile regions
# 
if(distribution=="Cauchy"){xlim.pl3 <- c(0, 3500); ylim.pl3 <- c(0, 3500)}
if(distribution=="Asymmetric"){xlim.pl3 <- c(0, 600); ylim.pl3 <- c(0, 120)}
if(distribution=="HT"){xlim.pl3 <- c(0, 110); ylim.pl3 <- c(0, 110)}
if(distribution=="Clover"){xlim.pl3 <- c(0, 8000); ylim.pl3 <- c(0, 50000)}

plot(data, xlim=xlim.pl3, ylim=ylim.pl3, pch=19, xlab=expression(x[1]), ylab=expression(x[2]))
points(realx1,realy1, type="l", lwd=2, lty=1)
points(realx2,realy2, type="l", lwd=2, lty=1)
points(realx3,realy3, type="l", lwd=2, lty=1)
lines(Q$Qset_P1_CovNum_1[,,2], lty=3, col="gray0", lwd=2)
lines(Q$Qset_P2_CovNum_1[,,2], lty=3, col="gray0", lwd=2)
lines(Q$Qset_P3_CovNum_1[,,2], lty=3, col="gray0", lwd=2)

#
# Plot 4,5,6: Quantile region with probability 1/750, 1/1500, 1/3000
# 
if(distribution=="Cauchy"){xlim.pl46 <- c(0,7400); ylim.pl46 <- c(0,7400)}
if(distribution=="Asymmetric"){xlim.pl46 <- c(0, 1100); ylim.pl46 <- c(0, 220)}
if(distribution=="HT"){xlim.pl46 <- c(0, 170); ylim.pl46 <- c(0, 170)}
if(distribution=="Clover"){xlim.pl46 <- c(0, 16000); ylim.pl46 <- c(0, 100000)}

for(j in 1:3){
  tmp.name <- paste("Qset_P",j,"_CovNum_1",sep="")
  tmp.quant <- Q[[tmp.name]]
  
  plot(data, xlim=xlim.pl46, ylim=ylim.pl46, type="n", pch=19, xlab=expression(x[1]), ylab=expression(x[2]))
  polygon(c(tmp.quant[,1,3], rev(tmp.quant[,1,1])), c(tmp.quant[,2,3], rev(tmp.quant[,2,1])), col="gray")
  points(get(paste("realx",j,sep="")), get(paste("realy",j,sep="")), type="l", lty=1, lwd=2)
  lines(tmp.quant[,,2], lty=3, col="gray0", lwd=2)
  lines(Q.EDhK[[paste("xn_hat",j,sep="")]], Q.EDhK[[paste("yn_hat",j,sep="")]], lty=2, lwd=2)
 
}

dev.copy2pdf(file=paste("CensQsets_",distribution,"_k0_",k0,"mass_version2.pdf",sep=""), height=4, width=6)

