b1=1
b2=length(actual_B)
PLOT_PARAMS = 1
PLOT_TIMES = 1
PLOT_PREDICTIONS = 1
lim_buff = 0.999
CEXBUFF=1.5
time_lim=c(0,7)
clNAMES = c("Classic", "Classic OvR","CL Uni classic OvR")
syNAMES = c("Mix histogram/classic","CL Uni Histogram OvR",
            "CL Uni Histogram OvR Independent")
clCOLOURS = c("black", "darkgrey","darkgrey")
syCOLOURS = c("black","darkgrey", "darkgrey")
clLTY = c(1,1,2,2)
syLTY = c(2,3,4)
leg_title = paste("Legend, # Rep =",Mrep)
#leg_title = paste("Legend")
leg_colours = c(clCOLOURS[which(clmodel_ind==1)],syCOLOURS[which(symodel_ind==1)])
leg_names = c(clNAMES[which(clmodel_ind==1)],syNAMES[which(symodel_ind==1)])
leg_lty = c(clLTY[which(clmodel_ind==1)],syLTY[which(symodel_ind==1)])



LTY = 1
LWD = 5
Mrep_ind = Mrep

if(Mrep_ind==1){
  mean_classic_MLE_FULL = classic_MLE_FULL[1:Mrep_ind,,]
  mean_classic_MLE = classic_MLE[1:Mrep_ind,,]
  mean_classic_MLE_U = classic_MLE_U[1:Mrep_ind,,]
  mean_symbolic_MLE_mix = symbolic_MLE_mix[1:Mrep_ind,,,]
  mean_symbolic_MLE_U = symbolic_MLE_U[1:Mrep_ind,,,]
  mean_symbolic_MLE_U_ind = symbolic_MLE_U_ind[1:Mrep_ind,,,]
  
  mean_time_classic_FULL = time_classic_FULL[1:Mrep_ind]
  mean_time_classic = time_classic[1:Mrep_ind]
  mean_time_classic_U = time_classic_U[1:Mrep_ind]
  mean_time_symbolic_mix = time_symbolic_mix[1:Mrep_ind,]
  mean_time_symbolic_U = time_symbolic_U[1:Mrep_ind,]
  mean_time_symbolic_U_ind = time_symbolic_U_ind[1:Mrep_ind,]

  mean_time_symbolic_mix_agg = time_symbolic_mix_agg[1:Mrep_ind,]
  mean_time_symbolic_U_agg = time_symbolic_U_agg[1:Mrep_ind,]
  mean_time_symbolic_U_ind_agg = time_symbolic_U_ind_agg[1:Mrep_ind,]
  
  mean_pred_classic = pred_classic[1:Mrep_ind]
  mean_pred_classic_FULL = pred_classic_FULL[1:Mrep_ind]
  mean_pred_classic_U = pred_classic_U[1:Mrep_ind]
  mean_pred_symbolic_mix = pred_symbolic_mix[1:Mrep_ind,]
  mean_pred_symbolic_U = pred_symbolic_U[1:Mrep_ind,]
  mean_pred_symbolic_U_ind = pred_symbolic_U_ind[1:Mrep_ind,]
}
if(Mrep_ind>1){
  mean_classic_MLE_FULL = apply(classic_MLE_FULL[1:Mrep_ind,,],c(2,3),mean)
  mean_classic_MLE = apply(classic_MLE[1:Mrep_ind,,],c(2,3),mean)
  mean_classic_MLE_U = apply(classic_MLE_U[1:Mrep_ind,,],c(2,3),mean)
  mean_symbolic_MLE_mix = apply(symbolic_MLE_mix[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_U = apply(symbolic_MLE_U[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_U_ind = apply(symbolic_MLE_U_ind[1:Mrep_ind,,,],c(2,3,4),mean)
  
  mean_time_classic_FULL = mean(time_classic_FULL[1:Mrep_ind])
  mean_time_classic = mean(time_classic[1:Mrep_ind])
  mean_time_classic_U = mean(time_classic_U[1:Mrep_ind])
  mean_time_symbolic_mix = apply(time_symbolic_mix[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U = apply(time_symbolic_U[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_ind = apply(time_symbolic_U_ind[1:Mrep_ind,],2,mean)
  
  mean_time_symbolic_mix_agg = apply(time_symbolic_mix_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_agg = apply(time_symbolic_U_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_ind_agg = apply(time_symbolic_U_ind_agg[1:Mrep_ind,],2,mean)
  
  mean_pred_classic_FULL = mean(pred_classic_FULL[1:Mrep_ind])
  mean_pred_classic = mean(pred_classic[1:Mrep_ind])
  mean_pred_classic_U = mean(pred_classic_U[1:Mrep_ind])
  mean_pred_symbolic_mix = apply(pred_symbolic_mix[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_U = apply(pred_symbolic_U[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_U_ind = apply(pred_symbolic_U_ind[1:Mrep_ind,],2,mean)
}


MEAN_SYMBOL_PRED = rbind(mean_pred_symbolic_mix,mean_pred_symbolic_U,mean_pred_symbolic_U_ind)
MEAN_SYMBOL_TIME = rbind(mean_time_symbolic_mix,mean_time_symbolic_U,mean_time_symbolic_U_ind)
MEAN_SYMBOL_TIME_AGG = rbind(mean_time_symbolic_mix_agg,mean_time_symbolic_U_agg,mean_time_symbolic_U_ind_agg)

MEAN_SYMBOL_TIME=MEAN_SYMBOL_TIME+MEAN_SYMBOL_TIME_AGG

MEAN_CLASSIC_PRED = c(mean_pred_classic_FULL,mean_pred_classic,mean_pred_classic_U)
MEAN_CLASSIC_TIME = c(mean_time_classic_FULL,mean_time_classic,mean_time_classic_U)

#Plot MLE averages
if(PLOT_PARAMS==1){
  par(mfrow=c(2,2))
  for(j in 1:(num_class)){
    for(i in 1:(num_var+1)){
      plot_ind = 0
      MAIN = paste("Param",j,",",i,"mean",sep="")
      PARAM_PLOT_CLASSIC = c(mean_classic_MLE_FULL[i,j],mean_classic_MLE[i,j],mean_classic_MLE_U[i,j])
      PARAM_PLOT_SYMBOLIC = rbind(mean_symbolic_MLE_mix[,i,j],mean_symbolic_MLE_U[,i,j],mean_symbolic_MLE_U_ind[,i,j])
      lim = c(PARAM_PLOT_CLASSIC,as.vector(PARAM_PLOT_SYMBOLIC[,b1:b2]))
      lim = lim[!is.nan(lim)]
      lim = lim[!is.infinite(lim)]
      lim = lim[lim!=0]
      for(pl in 1:dim(PARAM_PLOT_SYMBOLIC)[1]){
        if(plot_ind==0&symodel_ind[pl]==1){
          plot(actual_B[b1:b2],PARAM_PLOT_SYMBOLIC[pl,b1:b2],type="l",col=syCOLOURS[pl],lty=syLTY[pl],
               ylim=c(min(lim),max(lim)),main=MAIN,lwd=LWD,
               xlab="Number of bins",ylab="MLE")
          plot_ind = 1
        }
        if(plot_ind==1&symodel_ind[pl]==1){
          lines(actual_B[b1:b2],PARAM_PLOT_SYMBOLIC[pl,b1:b2],type="l",col=syCOLOURS[pl],lty=syLTY[pl],
                lwd=LWD)
        }
      }
      for(pl in 1:(length(clNAMES))){
        if(clmodel_ind[pl]==1){
          abline(h=PARAM_PLOT_CLASSIC[pl],col=clCOLOURS[pl],lty=clLTY[pl],lwd=LWD)
        }
      }
      abline(h=beta_matrix[i,j])
    }
  }
}
#Plot computation times
if(PLOT_TIMES==1){
  par(mfrow=c(1,1))
  plot_ind = 0
  lim=c(as.vector(MEAN_SYMBOL_TIME[,b1:b2]),MEAN_CLASSIC_TIME[1])
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  if(!is.null(time_lim)){
    #lim=time_lim
  }
  main="Average computation Times for MLE"
  main=NULL
  for(i in 1:(length(symodel_ind))){
    if(plot_ind==0&symodel_ind[i]==1){
      plot(actual_B[b1:b2],MEAN_SYMBOL_TIME[i,b1:b2],type="l",col=syCOLOURS[i],lty=syLTY[i],
           ylim=c(min(lim),max(lim)),main=main,xlab="Number of bins",lwd=LWD,
           ylab="Time (s)",cex.lab=CEXBUFF,cex.axis=CEXBUFF,yaxt='n')
      axis(side=2,at=c(0:10),cex.lab=CEXBUFF,cex.axis=CEXBUFF)
      plot_ind = 1
    }
    if(plot_ind==1&symodel_ind[i]==1){
      lines(actual_B[b1:b2],(MEAN_SYMBOL_TIME[i,b1:b2]),type="l",col=syCOLOURS[i],lty=syLTY[i],lwd=LWD)
    }
  }
  #legend("topright",title=leg_title,col=leg_colours,legend=leg_names,lty=leg_lty,lwd=LWD,cex=1)
  abline(h=(MEAN_CLASSIC_TIME[1]),col=clCOLOURS[1],lty=clLTY[1],lwd=LWD)
  abline(h=(MEAN_CLASSIC_TIME[2]),col=clCOLOURS[2],lty=clLTY[2],lwd=LWD)
  if(mean_time_classic_U>0){
    abline(h=(mean_time_classic_U),col=clCOLOURS[3],lty=clLTY[3],lwd=LWD)
    
  }
  #abline(h=(mean_time_classic_CL),col=clCOLOURS[4],lty=LTY,lwd=LWD)
}
#Plot predictions
if(PLOT_PREDICTIONS==1){
  par(mfrow=c(1,1))
  plot_ind = 0
  lim=c(as.vector(MEAN_SYMBOL_PRED[symodel_ind==1,b1:b2]),MEAN_CLASSIC_PRED[clmodel_ind==1])
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  lim = c(lim,min(lim)*lim_buff)
  for(i in 1:(length(symodel_ind))){
    if(plot_ind==0&symodel_ind[i]==1){
      main=paste("Density",model_num,"Average P.A. (%)")
      main=NULL
      plot(actual_B[b1:b2],MEAN_SYMBOL_PRED[i,b1:b2],type="l",col=syCOLOURS[i],lty=syLTY[i],
           ylim=c(min(lim),max(lim)),main=main,xlab="Number of bins",lwd=LWD,
           ylab="P.A. (%)",cex.lab=CEXBUFF,cex.axis=CEXBUFF)
      plot_ind = 1
    }
    if(plot_ind==1&symodel_ind[i]==1){
      lines(actual_B[b1:b2],(MEAN_SYMBOL_PRED[i,b1:b2]),type="l",col=syCOLOURS[i],lty=syLTY[i],lwd=LWD)
    }
  }
  abline(h=(mean_pred_classic_FULL),col=clCOLOURS[1],lty=clLTY[1],lwd=LWD)
  abline(h=(mean_pred_classic),col=clCOLOURS[2],lty=clLTY[2],lwd=LWD)
  abline(h=(mean_pred_classic_U),col=clCOLOURS[3],lty=clLTY[3],lwd=LWD)

}

legend("bottomright",title=leg_title,col=leg_colours,legend=leg_names,lty=leg_lty,lwd=LWD
,cex=1)
