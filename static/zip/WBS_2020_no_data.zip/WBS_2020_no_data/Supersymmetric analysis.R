library(glmnet)
library(cubature)
library(plyr)
library(squash) 
library(nleqslv)  
library(mnormt)
#library(R2Cuba) 
library(gsl)
library(sn)
library(bestNormalize)

setwd("~/Dropbox/Tom - Paper 2/submission_code")
source('functions.R')

simulation_name = "Supersymmetric"
SET_PARAMETERS = 1 
Mnrep = 1 

if(SET_PARAMETERS==1){
  aa = 6
  aa2 = 2
  #training data sample size
  N = 4.5*10^aa
  #test data sample size
  test_N = 0.5*10^aa
  #number of histogram bins
  actual_B = c(6,8,10,12,15,20,25)
  START_BETA = 0.00001
  ll=10
  #regularisation parameters - has been run with optimal parameters for this seed configuration given below
  LAM_VEC = c(1,2)
  LAM_VEC = c(LAM_VEC*10^(aa-6))
  n_LAM = length(LAM_VEC)
  #number of CV folds
  n_FOLDS = 10
  CROSS_VALIDATION = 0
  
  U_symbolic = 1
  U_orders = 1
  CLASSIC_sub = 1
  #subsampling sizes
  num_sub = 1000
  num_sub2 = 1000
  LAM =3
  #optimal CV parameters if CROSS_VALIDATION=0, previously determined
  LAM_sub=0.001
  LAM_u = c(253,210,673,317,317,150,150)
  LAM_orders= c(136,104,198,634,111,793,150)
  num_opt = 2
  n_LAM = length(LAM_VEC)
  uniform_sampling = 0
  constant <<- pi/sqrt(3)
  print_ind <<- 20000000
  VARYING_COUNTMAX = 3
  #optim parameters
  METHOD <<- "BFGS" 
  MAXIT = 5000
  RELTOL = 1e-8
  ptime = 1
  SAVE_RESULTS = 1
  CLASSIC = 0
  TOTAL_MAX_PRED <<- 0
  #calculate covariance information on subsample of data for efficiency purposes. Setting
  #aa=0 will result in the entire training dataset being used
  regress_size = 4.5*10^(aa-aa2)
  row_names = paste("LAM =",LAM_VEC)
  if(CROSS_VALIDATION==1){
    print("LAM VECTOR")
    print(round(LAM_VEC,3)) 
  }

}

if(!exists("scratch")){ 
  print("Getting data")
  #read in data
  DATA =read.table("supersymmetric.csv",nrow=N+test_N,header=T,sep=",")[,-1]
  set.seed(77) 
  #randomly split data between training and testing sets
  subset = sample.int(N+test_N,N)
  DATA2 = DATA
  for(i in 1:18){
    DATA2[,i]=(DATA2[,i]-mean(DATA2[,i]))/sd(DATA2[,i])
  }

  Xdata = DATA2[c(subset),-c(19)]

  Ydata = DATA2[c(subset),19]
  test_Xdata = DATA2[-c(subset),-c(19)]
  test_Ydata = DATA2[-c(subset),19]
  num_var = ncol(Xdata)
  num_class = length(unique(Ydata))
  old_Xdata = Xdata
  old_Ydata = Ydata
  oldtest_Xdata = test_Xdata
  oldtest_Ydata = test_Ydata
  
  train.data = cbind(old_Xdata,old_Ydata)
  test.data=cbind(oldtest_Xdata,oldtest_Ydata)
  print(paste("Cov(X)"))
  print(round(cov(Xdata),2))
  cov_errors_u = array(NA,dim = c(num_var,num_var-1,num_var-1))
  cov_errors_cl = array(NA,dim = c(num_var,num_var,num_var-2,num_var-2))
  samp=sample(1:N,regress_size)
  #get covariance information
  for(i1 in 1:num_var){
    resid = matrix(NA,nrow=(length(samp)), ncol = num_var)
    for(i2 in 1:num_var){
      if(i1!=i2){
        xx = as.numeric(Xdata[samp,i1])
        yy = as.numeric(Xdata[samp,i2])
        residuals=yy-((t(xx)%*%xx)^(-1))%*%t(xx)%*%yy%*%xx
        resid[,i2] = residuals
      }
    }
    cov_resid = cov(resid[,-c(i1)])
    cov_errors_u[i1,,] = cov_resid
  }
  errors_u = cov_errors_u
}
scratch = 1
 
CONTROL = list("fnscale"=-1, maxit=MAXIT, reltol =RELTOL )
PRED_C = 0

COMBS <<- NULL
num_bins = rep(NA, length(actual_B))

#store results
MLE_s_u = MLE_s_orders = array(0,dim=c(length(actual_B),num_var+1,num_class))
time_s_u=time_s_orders = rep(0,length(actual_B))
time_s_u_agg=time_s_orders_agg  = rep(0,length(actual_B))
pred_s_u=pred_s_orders = rep(0,length(actual_B))

vars = rep(NA,dim(Xdata)[2])
for(i in 1:num_var){
  vars[i] = var(Xdata[,i])
}

#Penalty function for regularisation
penalty_function <- function(beta){
  ret = sum(abs(beta^2))
  return(ret)
}


library(dplyr) 
ACT=1
PLOT=0
FINAL_PLOT=1
PREDICT = 1
Bbuff = 1e-5
PRINT=1

classic_MLE_sub = array(0, dim=c(Mnrep,num_var+1,num_class))
symbolic_MLE_U = symbolic_MLE_orders = array(0, dim=c(Mnrep,length(actual_B),num_var+1,num_class))

#store results
time_classic_sub  = rep(0,Mnrep)
pred_classic_sub=rep(0,Mnrep)
time_symbolic_U = time_symbolic_orders  = matrix(0,nrow=Mnrep,ncol=length(actual_B))
time_symbolic_U_agg = time_symbolic_orders_agg = matrix(0,nrow=Mnrep,ncol=length(actual_B))
pred_symbolic_U = pred_symbolic_orders = matrix(0,nrow=Mnrep,ncol=length(actual_B))
REP <<- 1

#perform CV
if(CROSS_VALIDATION==1){
  
  SETUP <<- 0
  pred_lam_s_u = pred_lam_c_sub = matrix(0,nrow=n_LAM, ncol=length(actual_B))
  pred_lam_s_orders = pred_lam_s_u
  fold_mult =  n_FOLDS/(n_FOLDS-1)
  column_names = paste("B =",actual_B)

  
  MAX_PRED = 0
  for(l in 1:length(LAM_VEC)){
    LAM = LAM_u =LAM_orders = rep(LAM_VEC[l],length(actual_B))
    for(n in 1:n_FOLDS){
      print(" ")
      print("NEW FOLD")
      #create test, train folds
      print(paste("LAM =",LAM_VEC[l],"| FOLD =",n))
      r1 = (n-1)*N/n_FOLDS+1
      r2 = n*N/n_FOLDS
      Xdata <<- train.data[-c(r1:r2),1:num_var]
      Xdata<<-matrix(unlist(Xdata),nrow=nrow(Xdata),ncol=ncol(Xdata))
      
      NN = nrow(Xdata)
      Ydata <<- train.data[-c(r1:r2),num_var+1]
      TEST_DATA <<-matrix(unlist(train.data[r1:r2,]),nrow=nrow(train.data[r1:r2,]),ncol=ncol(train.data[r1:r2,]))
      
      
      ERRORS = 1
      pred_c_sub=time_c_sub=time_c_sub_agg=0
      Ydata2=Ydata-1

      
      covX=cov(Xdata)
      #run analysis for CV configuration
      start_beta = rep(START_BETA,num_var+1)
      if(CLASSIC_sub==1){
        print("Classic Sub Sample")
        it <<- 2
        maxlik <<- -10^10
        maxpar <<- NULL
        time1 = proc.time()[ptime]
        samp1 = sample(1:NN,num_sub)
        optC = optim(start_beta,classic_lik2, X=Xdata[samp1,],Y=Ydata[samp1],lambda=0,
                     print=PRINT,control = CONTROL,method=METHOD)
        sub_par = optC$par
        SUB_MAT = cbind(matrix(sub_par,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
        weights = find_weights(Xdata,Ydata2,SUB_MAT)
        if(uniform_sampling==1){
          weights = rep(1,length(weights))
          weights = weights/sum(weights)
        }
        samp2 = sample(1:NN,num_sub2,prob=weights)
        samp = c(samp1,samp2)
        weights2 = c(rep(1/NN,length(samp1)),weights[samp2])
        time_c_sub_agg = proc.time()[ptime]-time1
        time2 = proc.time()[ptime]
        optC=NULL
        optC$par=start_beta
        for(rr in 1:num_opt){
          optC = optim(optC$par,classic_lik2, X=Xdata[samp,],Y=Ydata[samp],lambda=LAM_sub,
                       print=PRINT,control = CONTROL,weights=weights2,method=METHOD)
        }
        PAR = optC$par
        time_c_sub  = proc.time()[ptime]-time2
        MLE_c_sub = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
        pred_beta = MLE_c_sub
        if(PREDICT==1){
          pp = predict_test_data_VS(pred_beta,TEST_DATA)
          pred_c_sub = pp
          print(paste(round(100*pp,2),"% Correct",sep=""))
        }
      }
      
      for(b in 1:length(actual_B)){
        B <<- actual_B[b]
        if(U_orders==1){
          symbol_U = X_u=NULL
          time1 = proc.time()[ptime]
          for(i in 1:num_var){
            if(num_class==2){
              for(c in 1:(num_class-1)){
                dat = sort(Xdata[Ydata==c,i])
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                
                qqq=quantile(dat,c(0.01,0.99))
                ind1=dat>=qqq[1]&dat<=qqq[2]
                dat1=dat[ind1]
                dat2=dat[!ind1] 
                oseq=round(seq(1,length(dat1),l=B))
                seq=dat1[oseq]
                H = hist(c(dat1[-oseq],dat2),breaks = c(min(dat)-Bbuff,seq,max(dat)+Bbuff),plot=F)
                if(sum(H$counts==0)>0){
                  stop()
                }
                low = H$breaks[-(length(H$breaks))]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
                symbol_U = rbind(symbol_U,dat2)
                xdat2=cbind(seq,rep(i,length(seq)),rep(c,length(seq)),1)
                X_u = rbind(X_u,xdat2)
                dat = sort(Xdata[Ydata!=c,i])
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                qqq=quantile(dat,c(0.01,0.99))
                ind1=dat>=qqq[1]&dat<=qqq[2]
                dat1=dat[ind1]
                dat2=dat[!ind1] 
                oseq=round(seq(1,length(dat1),l=B))
                seq=dat1[oseq]
                H = hist(c(dat1[-oseq],dat2),breaks = c(min(dat)-Bbuff,seq,max(dat)+Bbuff),plot=F)
                if(sum(H$counts==0)>0){
                  stop()
                }
                low = H$breaks[-(length(H$breaks))]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
                symbol_U = rbind(symbol_U,dat2)
                xdat2=cbind(seq,rep(i,length(seq)),rep(c,length(seq)),2)
                X_u = rbind(X_u,xdat2)
              }
            }
          }
          time_s_orders_agg[b] = proc.time()[ptime]-time1
          it <<- 0
          maxlik <<- -10^10
          maxpar <<- NULL
          time1 = proc.time()[ptime]
          optS=NULL
          optS$par=start_beta
          for(rr in 1:num_opt){
            optS = optim(optS$par,symbolic_lik_orders_VS2, S=symbol_U,X=X_u,
                         lambda=LAM_orders[b],cov=covX,errors = errors_u
                         ,control = CONTROL,method=METHOD,print=TRUE)
          }
          
          time_s_orders[b] = proc.time()[ptime]-time1
          PAR = optS$par
          if(num_class==2){
            PAR = c(PAR,rep(0,num_var+1))
          }
          
          MLE_s_orders[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
          pred_beta = MLE_s_orders[b,,]
          if(PREDICT==1){
            pp = predict_test_data_VS(pred_beta,TEST_DATA)
            pred_s_orders[b] = pp
            print(paste(round(100*pp,2),"% Correct",sep=""))
          }
        }
        if(U_symbolic==1){
          symbol_U = NULL
          time1 = proc.time()[ptime]
          for(i in 1:num_var){
            if(num_class==2){
              for(c in 1:(num_class-1)){
                dat = Xdata[Ydata==c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-c(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
                symbol_U = rbind(symbol_U,dat2)
                dat = Xdata[Ydata!=c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-c(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
                symbol_U = rbind(symbol_U,dat2)
              }
            }
          }
          time_s_u_agg[b] = proc.time()[ptime]-time1
          it <<- 0
          maxlik <<- -10^10
          maxpar <<- NULL
          time1 = proc.time()[ptime]
          optS=NULL
          optS$par=start_beta
          for(rr in 1:num_opt){
            optS = optim(optS$par,symbolic_lik_U_VS2, S=symbol_U,
                         lambda=LAM_u[b],cov=covX,errors = errors_u
                         ,control = CONTROL,method=METHOD,print=TRUE)
          }
          time_s_u[b] = proc.time()[ptime]-time1
          PAR = optS$par
          if(num_class==2){
            PAR = c(PAR,rep(0,num_var+1))
          }
          
          MLE_s_u[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
          pred_beta = MLE_s_u[b,,]
          if(PREDICT==1){
            pp = predict_test_data_VS(pred_beta,TEST_DATA)
            pred_s_u[b] = pp
            print(paste(round(100*pp,2),"% Correct",sep=""))
          }
        }
      }
      
      pred_lam_s_u[l,] =  pred_lam_s_u[l,] + pred_s_u/n_FOLDS
      pred_lam_s_orders[l,] =  pred_lam_s_orders[l,] + pred_s_orders/n_FOLDS
      pred_lam_c_sub[l,] = pred_lam_c_sub[l,] + pred_c_sub/n_FOLDS
      print_table = rbind(pred_lam_s_u[l,],pred_lam_s_orders[l,],pred_lam_c_sub[l,])
      rownames(print_table) = c("Uni","Orders","Classic sub")
      colnames(print_table) = column_names
      print_table2 = print_table*n_FOLDS/n
      print(paste(l,"/",length(LAM_VEC)," completed. RESULTS: LAM = ",LAM_VEC[l]," | FOLD = ",n,sep=""))
      print(print_table2)
      max_pred = max(print_table)
      if(max_pred>MAX_PRED){
        MAX_PRED = max_pred
        ind1 = which(print_table == max(print_table), arr.ind = TRUE)
        MAX_B = actual_B[ind1[2]]
        MAX_MOD = rownames(print_table)[ind1[1]]
        MAX_LAM = LAM_VEC[l]
      }
      print(paste("Max Prediction = ",round(100*MAX_PRED,2),"%, Model = ",MAX_MOD,sep=""))
      print(paste("B = ",MAX_B,", LAM = ",MAX_LAM,sep=""))
      print("")
    }
    max_pred_s_u = apply(pred_lam_s_u,2,max)
    max_pred_s_orders = apply(pred_lam_s_orders,2,max)
    max_pred_c_sub = apply(pred_lam_c_sub,2,max)
    print_table = rbind(max_pred_s_u,max_pred_s_orders,max_pred_c_sub)
    column_names = paste("B =",actual_B)
    rownames(print_table) = c("Uni","Orders","Classic sub")
    colnames(print_table) = column_names
    print('MAX PREDICTION %')
    print(print_table)
    print_table = rbind(time_s_u+time_s_u_agg,time_s_orders+time_s_orders_agg
                        ,time_c_sub+time_c_sub_agg)
    rownames(print_table) = c("Uni","Orders","Classic sub")
    colnames(print_table) = column_names
    colnames(print_table) = column_names
    print("TIMES (s)")
    print(print_table)
  }
  
  colnames(pred_lam_s_u) = column_names
  rownames(pred_lam_s_u) = row_names
  colnames(pred_lam_c_sub) = column_names
  rownames(pred_lam_c_sub) = row_names
  colnames(pred_lam_s_orders) = column_names
  rownames(pred_lam_s_orders) = row_names
  print("UNI")
  print(pred_lam_s_u)
  print("UNI ORDERS")
  print(pred_lam_s_orders)
  print("CLASSIC SUB")
  print(pred_lam_c_sub)
  #get optimal CV parameters
  LAM_u =LAM_orders = LAM_sub=LAM = rep(0,length(actual_B))
  for(b in 1:length(actual_B)){
    LAM_u[b] = LAM_VEC[which.max(pred_lam_s_u[,b])]*fold_mult
    LAM_orders[b] = LAM_VEC[which.max(pred_lam_s_orders[,b])]*fold_mult
    LAM_sub[b]= LAM_VEC[which.max(pred_lam_c_sub[,b])]*fold_mult
  }
  max_pred_s_u = apply(pred_lam_s_u,2,max)
  max_pred_s_orders = apply(pred_lam_s_orders,2,max)
  max_pred_c_sub = apply(pred_lam_c_sub,2,max)
  print_table = rbind(max_pred_s_u,max_pred_s_orders,max_pred_c_sub)
  rownames(print_table) = c("Uni","Orders","Classic sub")
  colnames(print_table) = column_names
  print('PREDICTION %')
  print(print_table)
  
  
}
test_N = dim(test.data)[1] 
TEST_DATA <<- test.data
Xdata <<- old_Xdata
Ydata <<- old_Ydata

Xdata<<-matrix(unlist(Xdata),nrow=nrow(Xdata),ncol=ncol(Xdata))
TEST_DATA<<-matrix(unlist(TEST_DATA),nrow=nrow(TEST_DATA),ncol=ncol(TEST_DATA))
NN = nrow(Xdata)
Mrep = 1
SETUP = 0
REP <<- Mrep


ERRORS = 1
pred_c_sub=time_c_sub=time_c_sub_agg=0
Ydata2=Ydata-1


covX=cov(Xdata)

start_beta = rep(START_BETA,num_var+1)
if(CLASSIC_sub==1){
  print("Classic Sub Sample")
  it <<- 2
  maxlik <<- -10^10
  maxpar <<- NULL
  time1 = proc.time()[ptime]
  samp1 = sample(1:NN,num_sub)
  optC = optim(start_beta,classic_lik2, X=Xdata[samp1,],Y=Ydata[samp1],lambda=0,
               print=PRINT,control = CONTROL,method=METHOD)
  sub_par = optC$par
  SUB_MAT = cbind(matrix(sub_par,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
  weights = find_weights(Xdata,Ydata2,SUB_MAT)
  if(uniform_sampling==1){
    weights = rep(1,length(weights))
    weights = weights/sum(weights)
  }
  samp2 = sample(1:NN,num_sub2,prob=weights)
  samp = c(samp1,samp2)
  weights2 = c(rep(1/NN,length(samp1)),weights[samp2])
  time_c_sub_agg = proc.time()[ptime]-time1
  time2 = proc.time()[ptime]
  optC=NULL
  optC$par=start_beta
  for(rr in 1:num_opt){
    optC = optim(optC$par,classic_lik2, X=Xdata[samp,],Y=Ydata[samp],lambda=LAM_sub[1],
                 print=PRINT,control = CONTROL,weights=weights2,method=METHOD)
  }
  PAR = optC$par
  start_beta=optC$par
  time_c_sub  = proc.time()[ptime]-time2
  MLE_c_sub = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
  pred_beta = MLE_c_sub
  if(PREDICT==1){
    pp = predict_test_data_VS(pred_beta,TEST_DATA)
    pred_c_sub = pp
    print(paste(round(100*pp,2),"% Correct",sep=""))
  }
}


for(b in 1:length(actual_B)){
  B <<- actual_B[b]
  if(U_orders==1){
    symbol_U = X_u=NULL
    time1 = proc.time()[ptime]
    for(i in 1:num_var){
      if(num_class==2){
        for(c in 1:(num_class-1)){
          dat = sort(Xdata[Ydata==c,i])
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }

          qqq=quantile(dat,c(0.01,0.99))
          ind1=dat>=qqq[1]&dat<=qqq[2]
          dat1=dat[ind1]
          dat2=dat[!ind1] 
          oseq=round(seq(1,length(dat1),l=B))
          seq=dat1[oseq]
          H = hist(c(dat1[-oseq],dat2),breaks = c(min(dat)-Bbuff,seq,max(dat)+Bbuff),plot=F)
          if(sum(H$counts==0)>0){
            stop()
          }
          low = H$breaks[-(length(H$breaks))]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
          symbol_U = rbind(symbol_U,dat2)
          xdat2=cbind(seq,rep(i,length(seq)),rep(c,length(seq)),1)
          X_u = rbind(X_u,xdat2)
          dat = sort(Xdata[Ydata!=c,i])
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          qqq=quantile(dat,c(0.01,0.99))
          ind1=dat>=qqq[1]&dat<=qqq[2]
          dat1=dat[ind1]
          dat2=dat[!ind1] 
          oseq=round(seq(1,length(dat1),l=B))
          seq=dat1[oseq]
          H = hist(c(dat1[-oseq],dat2),breaks = c(min(dat)-Bbuff,seq,max(dat)+Bbuff),plot=F)
          if(sum(H$counts==0)>0){
            stop()
          }
          low = H$breaks[-(length(H$breaks))]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
          symbol_U = rbind(symbol_U,dat2)
          xdat2=cbind(seq,rep(i,length(seq)),rep(c,length(seq)),2)
          X_u = rbind(X_u,xdat2)
        }
      }
    }
    time_s_orders_agg[b] = proc.time()[ptime]-time1
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    time1 = proc.time()[ptime]
    optS=NULL
    optS$par=start_beta
    for(rr in 1:num_opt){
      optS = optim(optS$par,symbolic_lik_orders_VS2, S=symbol_U,X=X_u,
                   lambda=LAM_orders[b],cov=covX,errors = errors_u
                   ,control = CONTROL,method=METHOD,print=TRUE)
    }
    
    time_s_orders[b] = proc.time()[ptime]-time1
    PAR = optS$par
    if(num_class==2){
      PAR = c(PAR,rep(0,num_var+1))
    }
     
    MLE_s_orders[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_s_orders[b,,]
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_s_orders[b] = pp
      print(paste(round(100*pp,2),"% Correct",sep=""))
    }
  }
  if(U_symbolic==1){
    symbol_U = NULL
    time1 = proc.time()[ptime]
    for(i in 1:num_var){
      if(num_class==2){
        for(c in 1:(num_class-1)){
          dat = Xdata[Ydata==c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-c(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
          symbol_U = rbind(symbol_U,dat2)
          dat = Xdata[Ydata!=c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-c(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
          symbol_U = rbind(symbol_U,dat2)
        }
      }
    }
    time_s_u_agg[b] = proc.time()[ptime]-time1
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    time1 = proc.time()[ptime]
    optS=NULL
    optS$par=start_beta
    for(rr in 1:num_opt){
      optS = optim(optS$par,symbolic_lik_U_VS2, S=symbol_U,
                   lambda=LAM_u[b],cov=covX,errors = errors_u
                   ,control = CONTROL,method=METHOD,print=TRUE)
    }
    time_s_u[b] = proc.time()[ptime]-time1
    PAR = optS$par
    if(num_class==2){
      PAR = c(PAR,rep(0,num_var+1))
    }
     
    MLE_s_u[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_s_u[b,,]
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_s_u[b] = pp
      print(paste(round(100*pp,2),"% Correct",sep=""))
    }
  }
}


