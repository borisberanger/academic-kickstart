#Need to install all of these packages

library(glmnet)
library(cubature)
library(plyr)
library(dplyr) 
library(squash) 
library(nleqslv)  
library(mnormt)
library(gsl)
library(sn)
library(bestNormalize)
library(mvQuad)
library(Rfast)

#Change this directory to the code/data location
setwd("~/Dropbox/Tom - Paper 2/submission_code")
source('functions.R')

#START_SEED is the random seed. Change this for different simulated parameter values,
  #data and covariance matrix.
#The results in the manuscript will not be exactly replicated, as it depends on the seed and 
#the code has been cleaned up since they were produced, however any start seed will give comparable results

START_SEED = 10
simulation_name = "MODEL1"
SET_PARAMETERS = 1 
VARYING <<- "B"
job.number = 1 

# Number of replications
Mnrep = 1000




if(SET_PARAMETERS==1){
  quick_test = 0
  
  set.seed(START_SEED) 
  
  #These are the main parameters of the simulation
  N = 25000
  #either NORMAL or SKEWNORMAL for densities in manuscript
  DENSITY = "SKEWNORMAL"
  num_class = 3
  num_var =5
  actual_B = c(3:15)
  countmax2 = 2^num_var
  
  #These variables determine which models are run
  #FULL_CLASSIC refers to the multinoial classic model, while CLASSIC refers to the OvR model
  U_symbolic = 1
  U_symbolic_ind = 1
  MIX_symbolic = 1
  FULL_CLASSIC = 1
  CLASSIC = 0
  U_CLASSIC = 0
  
  #Set the maximum correlation value (uniformly simulated up to this amount).
  #For independent covariates, set to a very small number (1e-8)
  CORRELATION_BUFF = 1e-10
  
  regress_size = N
  maxskew = 10
  unif_range = 2
  constant <<- pi/sqrt(3)
  METHOD <<- "BFGS" 
  MAXIT = 1000
  num_opt=2
  MAX_EVAL <<- 2
  RELTOL = 1e-10
  ptime = 1
  SAVE_RESULTS = 0
  SETUP = 1
  NUM_VAR = num_var
  NUM_CLASS = num_class
  start_buff = 0.1
  zero_start_beta=1
  model_num = 1
  PRINT=0
  print_ind <<- 10^9
  TOTAL_MAX_PRED <<- 0
  LAM = 0
  LAM_u = LAM_mix= rep(LAM,length(actual_B))
}


clmodel_ind = c(FULL_CLASSIC,CLASSIC,U_CLASSIC)
symodel_ind = c(MIX_symbolic,U_symbolic,U_symbolic_ind)
ACT=1
PLOT=0
FINAL_PLOT=1
PREDICT = 1
Bbuff = 1/N
set.seed(START_SEED)
#generate true parameter
actual_beta_vec = runif((num_class)*(num_var+1),-2,2)
actual_beta = actual_beta_vec
beta_matrix = matrix(actual_beta,nrow = num_var+1,ncol = num_class)
print(beta_matrix)
varcov = matrix(1,nrow=num_var,ncol=num_var)
pdef = 0
#simulate covariance matrix
while(pdef==0){
  for(i in 1:(num_var-1)){
    for(j in (i+1):num_var){
      varcov[i,j] = varcov[j,i] = runif(1,-CORRELATION_BUFF,CORRELATION_BUFF)
      #varcov[i,j] = varcov[j,i] = CORRELATION_BUFF
    }
  }
  eig = eigen(varcov,symmetric=TRUE)
  if(sum(eig$values>0)==num_var){
    pdef = 1
  }
}
skew_param = runif(num_var,0,maxskew)

ACT_BETA <<- beta_matrix
print(paste("ACTUAL BETA"))
print(beta_matrix)
print(paste("Cov(X)"))
print(varcov)

#Create tables to store results
classic_MLE_FULL = classic_MLE = classic_MLE_U = array(0, dim=c(Mnrep,num_var+1,num_class))
symbolic_MLE_mix  = symbolic_MLE_U=symbolic_MLE_U_ind = array(0, dim=c(Mnrep,length(actual_B),num_var+1,num_class))

time_classic = time_classic_FULL =time_classic_U = rep(0,Mnrep)
pred_classic_FULL=pred_classic=pred_classic_U = rep(0,Mnrep)
time_symbolic_mix = time_symbolic_U=time_symbolic_U_ind = matrix(0,nrow=Mnrep,ncol=length(actual_B))
time_symbolic_mix_agg = time_symbolic_U_agg=time_symbolic_U_ind_agg   = matrix(0,nrow=Mnrep,ncol=length(actual_B))
pred_symbolic_mix = pred_symbolic_U =pred_symbolic_U_ind = matrix(0,nrow=Mnrep,ncol=length(actual_B))



for(Mrep in 1:Mnrep){
  REP <<- Mrep

  print(paste('Mrep =',Mrep))
  ERRORS = 1
  num_class = NUM_CLASS
  #Simulate covariate data
  if(SETUP==1){
    if(DENSITY=="NORMAL"){ 
      Xdata = rmnorm(N,rep(0,num_var),varcov)
      test_Xdata = rmnorm(N,rep(0,num_var),varcov)
    }
    if(DENSITY=="SKEWNORMAL"){
      Xdata = rmsn(N,rep(0,num_var),Omega=varcov,alpha=skew_param)
      test_Xdata = rmsn(N,rep(0,num_var),Omega=varcov,alpha=skew_param)
    }
    if(DENSITY=="UNIFORM"){
      Xdata = matrix(runif(num_var*N,-unif_range,unif_range),nrow=N,ncol=num_var)
      test_Xdata = matrix(runif(num_var*N,-unif_range,unif_range),nrow=N,ncol=num_var)
    }
    if(DENSITY=="EXP"){
      Xdata = matrix(rexp(num_var*N,2),nrow=N,ncol=num_var)
      test_Xdata = matrix(rexp(num_var*N,2),nrow=N,ncol=num_var)
    }
    for(nn in 1:num_var){
      Xdata[,nn] = (Xdata[,nn]-mean(Xdata[,nn]))/sd(Xdata[,nn])
      test_Xdata[,nn] = (test_Xdata[,nn]-mean(Xdata[,nn]))/sd(Xdata[,nn])
    }
    print(paste("Cov(X)"))
    print(round(cov(Xdata),2))
    XX = cbind(rep(1,N),Xdata)
    test_XX = cbind(rep(1,N),test_Xdata)
    predictions = test_predictions = matrix(NA, nrow = N,ncol = num_class)
    #simulate responses
    denom = test_denom = rep(0,N)
    for(i in 1:num_class){
      temp_denom = apply(XX,1,function(x){exp(sum(x*beta_matrix[,i]))})
      denom = denom+temp_denom
      predictions[,i] = temp_denom
      temp_denom = apply(test_XX,1,function(x){exp(sum(x*beta_matrix[,i]))})
      test_denom = denom+temp_denom
      test_predictions[,i] = temp_denom
    }
    for(i in 1:num_class){
      predictions[,i] = predictions[,i]/denom
      test_predictions[,i] = test_predictions[,i]/test_denom
    }
    Ydata = apply(predictions,1,sample_X)
    test_Ydata = apply(test_predictions,1,sample_X)
    
    if(Mrep==1){
      par(mfrow=c(1,1))
      hist(Ydata)
    }
    if(length(unique(Ydata))!=num_class){
      stop()
    }
    
    #starting parameter
    start_beta2 = as.vector(beta_matrix)
    start_beta2 = start_beta2*runif(length(start_beta2),1-start_buff,1+start_buff)
    start_beta = head(start_beta2,-(num_var+1))
    if(zero_start_beta==1){
      start_beta=start_beta*0+1e-4
      start_beta2=start_beta2*0+1e-4
    }
    TEST_DATA = cbind(test_XX[,-1],test_Ydata)
    CONTROL = list("fnscale"=-1, maxit=MAXIT, reltol =RELTOL )
    PRED_C = 0
    
    COMBS <<- NULL
    num_bins = rep(NA, length(actual_B))
    MLE_s = MLE_s_mix = MLE_s_u  = MLE_s_u_ind = array(0,dim=c(length(actual_B),num_var+1,num_class))
    time_s = time_s_mix= time_s_u = time_s_u_ind = rep(0,length(actual_B))
    time_s_agg = time_s_mix_agg= time_s_u_agg = time_s_u_ind_agg = rep(0,length(actual_B))
    pred_s = pred_s_mix= pred_s_u = pred_s_u_ind = rep(0,length(actual_B))
    
    vars = rep(NA,dim(Xdata)[2])
    for(i in 1:num_var){
      vars[i] = var(Xdata[,i])
    }
  }
  
  #Obtain covariance information
  if(ERRORS==1&SETUP==1){
    errors_u = array(NA,dim = c(num_var,num_var))
    cov_errors_u=cov_errors_u2 = array(NA,dim = c(num_var,num_var-1,num_var-1))
    for(i1 in 1:num_var){
      resid = matrix(NA,nrow=dim(Xdata)[1], ncol = num_var)
      for(i2 in 1:num_var){
        if(i1!=i2){
          xx = as.numeric(Xdata[1:regress_size,i1])
          yy = as.numeric(Xdata[1:regress_size,i2])
          m = lm(yy~xx)
          errors_u[i1,i2] = sd(m$residuals)
          resid[,i2] = m$residuals
        }
      }
      cov_resid = cov(resid[,-c(i1)])
      cov_errors_u[i1,,] = cov_resid
      cov_errors_u2[i1,,] = 0
      diag(cov_errors_u2[i1,,]) = 1
    }
    errors_u = cov_errors_u
    errors_u2 = cov_errors_u2
  }
  
  #Multinomial classic model
  if(FULL_CLASSIC==1){
    print("Classic")
    time1 = proc.time()[ptime]
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    LAM2 = LAM
    if(length(LAM2)>1){
      LAM2 = LAM[l]
    }
    optC=NULL
    optC$par=start_beta
    for(rr in 1:num_opt){
      optC = optim(optC$par,classic_lik, X=Xdata,Y=Ydata,lambda=LAM2,
                   print=PRINT,control = CONTROL,method=METHOD)
    }
    
    time_c_full = proc.time()[ptime]-time1
    PAR = optC$par
    temp_classic_beta_full = PAR
    MLE_c_full = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
    pred_beta = MLE_c_full
    if(PREDICT==1){
      pp = predict_test_data(pred_beta,TEST_DATA)
      pred_c_full = pp
      PRED_C <<- pred_c_full
    }
  }
  #OvR classic model
  if(CLASSIC==1){
    print("Classic vs")
    time1 = proc.time()[ptime]
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    PRINT2=PRINT
    PRINT2=1
    optC=NULL
    optC$par=start_beta2
    for(rr in 1:num_opt){
      optC = optim(optC$par,classic_lik_VS, X=Xdata,Y=Ydata,lambda=LAM[1],
                   print=0,control = CONTROL,method=METHOD)
    }
    
    time_c = proc.time()[ptime]-time1
    PAR = optC$par
    MLE_c = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_c
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_c = pp
      PRED_C <<- pred_c
    }
  }
  #Classic Univariate model
  if(U_CLASSIC==1){
    print("Classic U")
    X_u = NULL
    for(i in 1:num_var){
      for(c in 1:num_class){
        dat = cbind(Xdata[Ydata==c,i],i,c,1)
        colnames(dat) = 1:dim(dat)[2]
        X_u = rbind(X_u,dat)
        dat = cbind(Xdata[Ydata!=c,i],i,c,2)
        colnames(dat) = 1:dim(dat)[2]
        X_u = rbind(X_u,dat)
      }
    }
    time1 = proc.time()[ptime]
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    optC=NULL
    optC$par=start_beta2
    for(rr in 1:num_opt){
      optC = optim(optC$par,classic_lik_U_VS, X=X_u,lambda=LAM_u[1],errors = errors_u,
                   cov=cov(Xdata),control = CONTROL,method=METHOD)
    }
    
    time_c_u = proc.time()[ptime]-time1
    PAR = optC$par
    MLE_c_u = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_c_u
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_c_u = pp
    }
  }
  
  for(b in 1:length(actual_B)){
    B <<- actual_B[b]
    #Univariate model with covariate information
    if(U_symbolic==1){
      print(paste("UNI | B = ",B,sep=""))
      symbol_U = NULL
      time1 = proc.time()[ptime]
      #create set of histograms
      for(i in 1:num_var){
        if(num_class>1){
          for(c in 1:num_class){
            dat = Xdata[Ydata==c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
            symbol_U = rbind(symbol_U,dat2)
            dat = Xdata[Ydata!=c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
            symbol_U = rbind(symbol_U,dat2)
          }
        }
      }
      time_s_u_agg[b] = proc.time()[ptime]-time1
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      cov=cov(Xdata)
      time1 = proc.time()[ptime]
      optS=NULL
      optS$par = start_beta2
      S=symbol_U
      errors = errors_u
      #optimise likelihood
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                     lambda=LAM_u[b],cov=cov,errors = errors_u
                     ,control = CONTROL,method=METHOD,print=PRINT)
      }
      
      time_s_u[b] = (proc.time()[ptime]-time1)
      PAR = optS$par
      MLE_s_u[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
      pred_beta = MLE_s_u[b,,]
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_u[b] = pp
      }
    }
    #Univariate model assuming covariate independence
    if(U_symbolic_ind==1){
      print(paste("UNI ind. | B = ",B,sep=""))
      symbol_U = NULL
      time1 = proc.time()[ptime]
      for(i in 1:num_var){
        if(num_class>1){
          for(c in 1:num_class){
            dat = Xdata[Ydata==c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
            symbol_U = rbind(symbol_U,dat2)
            dat = Xdata[Ydata!=c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
            symbol_U = rbind(symbol_U,dat2)
          }
        }
      }
      time_s_u_ind_agg[b] = proc.time()[ptime]-time1
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      aa = proc.time()[ptime]
      cov=cov(Xdata)
      time1 = proc.time()[ptime]
      optS=NULL
      optS$par=start_beta2
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                     lambda=LAM_u[b],cov=cov,errors = errors_u2
                     ,control = CONTROL,method=METHOD,print=TRUE)
      }
      time_s_u_ind[b] = proc.time()[ptime]-time1+time_s_u_agg[b]
      PAR = optS$par     
      if(num_class==2){      
        PAR = c(PAR,rep(0,num_var+1))     
      }
      MLE_s_u_ind[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
      pred_beta = MLE_s_u_ind[b,,] 
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_u_ind[b] = pp
      }
    }
    #Mixed classic/histogram model
    if(MIX_symbolic==1){
      print(paste("MIX | B = ",B,sep=""))
      symbol = array(NA,dim=c(B+1,num_var,num_class))
      time1 = proc.time()[ptime]
      
      for(m in 1:num_var){
        for(c in 1:num_class){
          ind = which(Ydata==c)
          dat = Xdata[ind,m]
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          bins = seq(min,max,l=B+1)
          quans = seq(0,1,l=B+1)
          symbol[,m,c]=bins
        }
      }
      Y = Ydata
      X = Xdata[,1:num_var]
      #obtain D-dimensional histogram, retaining the classical observations which go in low count bins
      symbol2 = histk(Xdata[,1:num_var],Y,symbol,countmax2)
      
      num_bins[b] = length(symbol2$class)
      rem_ind = NULL
      full_data = cbind(Xdata,Ydata)
      pointwise_data=full_data[symbol2$retain_classic_ind==1,]
      
      cc = symbol2$lower[,1] 
      rem_ind = which(cc<countmax2)
      
      it <<- 0
      symbol3=symbol2
      symbol3$lower = symbol2$lower[-c(rem_ind),]
      symbol3$upper = symbol2$upper[-c(rem_ind),]
      symbol3$class = symbol2$class[-c(rem_ind)]
      
      data = cbind(pointwise_data,1:nrow(pointwise_data),1)
      data=matrix(unlist(data),nrow=nrow(data),ncol=ncol(data))
      counts2=c(rep(1,nrow(data)),rep(NA,length(symbol3$class)+4))
      cit=naind=nrow(data)+1
      colnames(data)=NULL
      llll=(length(symbol3$class)+4)*MAX_EVAL^num_var
      data=rbind(data,matrix(NA,nrow=llll,ncol=num_var+3))
      if(is.null(nrow(symbol3$lower))){
        if(length(symbol3$lower)==0){
          symbol3$lower=symbol2$lower[1:num_class,]
          symbol3$upper=symbol2$upper[1:num_class,]
          symbol3$lower[,1]= symbol3$upper[,1]=0
          symbol3$class  =1:num_class
          pointwise_data=cbind(Xdata,Ydata)
        }
        if(length(symbol3$lower)>0){
          symbol3$lower=rbind(symbol3$lower,symbol2$lower[1,])
          symbol3$upper=rbind(symbol3$upper,symbol2$upper[1,])
          symbol3$lower[2,1]= symbol3$upper[2,1]=0
          symbol3$class  =c(symbol3$class,1)
        }
      }
      
      
      nbre=MAX_EVAL+1
      cbre=1:MAX_EVAL
      kkk=MAX_EVAL^num_var
      #Obtain points for quadrature
      if(!is.null(nrow(symbol3$lower))){
        if((nrow(symbol3$lower))==0|(nrow(symbol3$lower))==1){
          symbol3$lower=symbol2$lower[1:num_class,]
          symbol3$upper=symbol2$upper[1:num_class,]
          symbol3$lower[,1]= symbol3$upper[,1]=0
          symbol3$class  =1:num_class
          pointwise_data=cbind(Xdata,Ydata)
        }
        else{
          for(bb in 1:nrow(symbol3$lower)){
            seqs=matrix(symbol3$lower[bb,-1],ncol=num_var,nrow=MAX_EVAL,byrow=T)+
              matrix(cbre,ncol=num_var,nrow=MAX_EVAL)*matrix(symbol3$upper[bb,-1]-symbol3$lower[bb,-1],ncol=num_var,nrow=MAX_EVAL,byrow=T)/nbre
            #Need to add seq[,k] for k variables below
            data[naind:(naind+kkk-1),] = matrix(unlist(cbind(expand.grid(seqs[,1],seqs[,2],seqs[,3],seqs[,4],seqs[,5])
                                                             ,symbol3$class[bb], nrow(pointwise_data)+bb,symbol3$lower[bb,1])),
                                                nrow=kkk,ncol=num_var+3)
            naind=naind+kkk
            counts2[cit+bb-1]=symbol3$lower[bb,1]
          }
        }
      }
      time_s_mix_agg[b] = proc.time()[ptime]-time1
      naind=which(is.na(data[,1]))[1]
      cnaind=which(is.na(counts2))[1]
      counts2=counts2[1:(cnaind-1)]
      data=data[1:(naind-1),]
      S=symbol3
      X=pointwise_data
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      optS=NULL
      optS$par=start_beta
      
      XX=data[,1:num_var]
      Y=data[,num_var+1]
      nobs=data[,num_var+2]
      counts=data[,num_var+3] 
      counts2=counts2
      time1 = proc.time()[ptime]
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_mix,XX=data[,1:num_var],
                     Y=data[,num_var+1],nobs=data[,num_var+2],counts=data[,num_var+3],
                     counts2=counts2,
                     lambda=LAM_mix[b],control = CONTROL,method=METHOD)
      }
      time_s_mix[b] = (proc.time()[ptime]-time1)
      PAR = optS$par
      MLE_s_mix[b,,] = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_s_mix[b,,]
      if(PREDICT==1){
        pp = predict_test_data(pred_beta,TEST_DATA)
        pred_s_mix[b] = pp
      }
    }
  }
  
  
  REP <<- Mrep
  par(mfrow=c(3,4))
  if(FULL_CLASSIC==1){
    classic_MLE_FULL[Mrep,,] = MLE_c_full
    time_classic_FULL[Mrep] = time_c_full
    if(PREDICT==1){
      pred_classic_FULL[Mrep] = pred_c_full
    }
  }
  if(CLASSIC==1){
    classic_MLE[Mrep,,] = MLE_c
    time_classic[Mrep] = time_c
    if(PREDICT==1){
      pred_classic[Mrep] = pred_c
    }
  }
  if(U_CLASSIC==1){
    classic_MLE_U[Mrep,,] = MLE_c_u
    time_classic_U[Mrep] = time_c_u
    if(PREDICT==1){
      pred_classic_U[Mrep] = pred_c_u
    }
  }
  if(MIX_symbolic==1){
    symbolic_MLE_mix[Mrep,,,] = MLE_s_mix
    time_symbolic_mix[Mrep,] = time_s_mix
    time_symbolic_mix_agg[Mrep,] = time_s_mix_agg
    if(PREDICT==1){
      pred_symbolic_mix[Mrep,] = pred_s_mix
    }
  }
  if(U_symbolic==1){
    symbolic_MLE_U[Mrep,,,] = MLE_s_u
    time_symbolic_U[Mrep,] = time_s_u
    time_symbolic_U_agg[Mrep,] = time_s_u_agg
    if(PREDICT==1){
      pred_symbolic_U[Mrep,] = pred_s_u
    }
  }
  if(U_symbolic_ind==1){
    symbolic_MLE_U_ind[Mrep,,,] = MLE_s_u_ind
    time_symbolic_U_ind[Mrep,] = time_s_u_ind
    time_symbolic_U_ind_agg[Mrep,] = time_s_u_ind_agg
    if(PREDICT==1){
      pred_symbolic_U_ind[Mrep,] = pred_s_u_ind
    }
  }
  source('sim41_plot.R')

}

