#FUNCTIONS
prob_tol <<- 1e-300
prob_tol2 <<- 1e-5
prob_tol3 <<- 1e-3
neg_ret <<- -1e+30  
beta_max <<- 300
ret1_length <<- 2000 
lhop_tol = 1e-1


#Univariate histogram likelihood, K>2 response categories
symbolic_lik_U_VS <- function(beta, S,cov,errors, lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  BETABETA<<-beta
  vars = diag(cov)
  num_var = length(unique(S[,4]))
  num_class = length(unique(S[,5]))
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  betacov = betacov2 = array(NA,dim = c(num_var,num_var,num_class))
  
  counts = S[,3]
  S2=S[counts>0,]
  
  beta_u = matrix(NA,nrow=nrow(S2),ncol=2)
  for(cc in 1:num_class){
    for(d1 in 1:num_var){
      betacov2[d1,,cc] = beta_mat[-1,cc]*cov[d1,]/vars[d1]
    }
    for(vv in 1:num_var){
      b0 = beta_mat[1,cc]
      b1 = beta_mat[vv+1,cc]
      coeff = sum(betacov2[vv,-c(vv),cc])
      v = sqrt(1+sum(errors[vv,,]*beta_mat[-c(1,vv+1),cc]%*%t(beta_mat[-c(1,vv+1),cc]))/constant^2)
      ind=S2[,4]==vv&S2[,5]==cc
      beta_u[ind==1,]=matrix(c(b0,b1+coeff)/v,nrow=sum(ind),ncol=2,
                             byrow=1)
    }
  }
  r1 = exp(beta_u[,1]+beta_u[,2]*S2[,1])+1
  r2 = exp(beta_u[,1]+beta_u[,2]*S2[,2])+1
  r3 = (log(r2)-log(r1))/(beta_u[,2])
  r41 = r3
  r42 = (S2[,2]-S2[,1])-r3
  ret1 = rep(NA,length(r1))
  ret1[S2[,6]==1]=r41[S2[,6]==1]
  ret1[S2[,6]==2]=r42[S2[,6]==2]
  lik = 0
  if(sum(is.nan(ret1))>0){
    return(neg_ret)
  }
  if(sum(ret1==0|is.nan(ret1)|is.infinite(ret1)|is.na(ret1))>0){
    return(neg_ret)
  }
  ret2 = S2[,3]*log(ret1)
  lik = sum(ret2)
  if(is.nan(lik)|is.infinite(lik)){
    return(neg_ret)
  }
  if(lambda>0){
    lik = lik-lambda/2*penalty_function(beta_mat)
  }
  return(lik)
}
#Mix classic/histogram likelihood
symbolic_lik_mix <- function(beta,XX,Y,nobs,counts,counts2,lambda=0){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  num_var = ncol(XX)
  ncobs=nrow(XX)
  X = cbind(1,XX)
  num_class = length(beta)/(num_var+1)+1
  beta_mat = cbind(matrix(beta,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
  numer = denom=rep(0,ncobs)
  for(i in 1:num_class){
    temp_denom = exp(X%*%beta_mat[,i])
    denom = denom+temp_denom
    numer[Y==i] = temp_denom[Y==i]
  }
  probs = numer/denom
  count_ind = which(counts>1)[1]
  if(is.na(count_ind)){
    count_ind=ncobs+1
  }
  probs1 = probs[1:(count_ind-1)]
  if(count_ind<ncobs){
    probs1 = c(probs1,colMeans(matrix(probs[count_ind:ncobs], nrow=MAX_EVAL^num_var)))
  }
  ret1 = counts2*log(probs1) 
  ret2 = sum(ret1)
  if(is.nan(ret2)){
    return(neg_ret)
  }
  if(lambda>0){
    ret2 = ret2-lambda/2*penalty_function(beta_mat)
  }
  return(ret2)
}
#Univariate histogram naive likelihood
symbolic_lik_U_VS3 <- function(beta, S,cov,errors, lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  beta = c(beta,rep(0,length(beta)))
  BETABETA<<-beta
  vars = diag(cov)
  num_var = length(unique(S[,4]))
  num_class = 2
  counts = S[,3]
  S2=S[counts>0,]
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  betacov = betacov2 = array(0,dim = c(num_var,num_var,num_class))
  beta_u = matrix(NA,nrow=nrow(S2),ncol=2)
  cc=1
  for(vv in 1:num_var){
    b0 = beta_mat[1,cc]
    b1 = beta_mat[vv+1,cc]
    ind=S2[,4]==vv
    beta_u[ind==1,]=matrix(c(b0,b1),nrow=sum(ind),ncol=2,
                           byrow=1)
  }
  
  r1 = exp(beta_u[,1]+beta_u[,2]*S2[,1])+1
  r2 = exp(beta_u[,1]+beta_u[,2]*S2[,2])+1
  r3 = (log(r2)-log(r1))/(beta_u[,2])
  r41 = r3
  r42 = (S2[,2]-S2[,1])-r3
  ret1 = rep(NA,length(r1))
  ret1[S2[,6]==1]=r41[S2[,6]==1]
  ret1[S2[,6]==2]=r42[S2[,6]==2]
  ret2 = S2[,3]*log(ret1)
  lik = sum(ret2)
  if(is.nan(lik)|is.infinite(lik)){
    return(neg_ret)
  }
  if(lambda>0){
    lik = lik-lambda/2*penalty_function(beta_mat)
  }
  return(lik)
}
#Pairwise Histogram likelihood K=2 classes
symbolic_lik_CL_VS <- function(beta, S, lambda=0,cov,errors,bbb,print=TRUE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  BETABETA <<- beta
  combs = sort(unique(S[,7]))
  num_class = length(unique(S[,6]))
  v1 = paste(S[dim(S)[1],7])
  v2 = regexpr('-',v1)
  v3 = as.numeric(substr(v1,v2[1]+1,nchar(v1)))
  num_var = v3
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  vars = diag(cov)
  counts = as.numeric(S[,5])
  S2=S[counts>0,]
  beta_cl = matrix(NA,nrow=nrow(S2),ncol=3)
  big_beta = array(NA,dim = c(3,2,num_class,num_var,num_var))
  for(cc in 1:num_class){
    for(vv1 in 1:(num_var-1)){
      for(vv2 in (vv1+1):(num_var)){
        big_beta[,2,cc,vv1,vv2] = 0
        b0 = beta_mat[1,cc]
        b1 = beta_mat[vv1+1,cc]
        b2 = beta_mat[vv2+1,cc]
        v1 = errors[vv1,vv2,,]
        v2 = beta_mat[-c(1,vv1+1,vv2+1),cc]%*%t(beta_mat[-c(1,vv1+1,vv2+1),cc])
        v = v1*v2
        v = sqrt(1+sum(v)/constant^2)
        coeff1 = bbb[-c(vv1,vv2),1,vv1,vv2]*beta_mat[-c(1,vv1+1,vv2+1),cc]
        coeff2 = bbb[-c(vv1,vv2),2,vv1,vv2]*beta_mat[-c(1,vv1+1,vv2+1),cc]
        new_b0 = b0/v
        coeff1 = sum(coeff1)
        coeff2 = sum(coeff2)
        new_b1 = (b1+coeff1)/v
        new_b2 = (b2+coeff2)/v
        big_beta[,1,cc,vv1,vv2] = c(new_b0,new_b1,new_b2)
        ind=S2[,7]==paste(vv1,"-",vv2,sep="")
        beta_cl[ind==1,]=matrix(c(new_b0,new_b1,new_b2),nrow=sum(ind),ncol=3,
                                byrow=1)
      }
    }
  }
  lik = 0
  
  
  #####
  nv = 2
  DAT7 = paste(S2[,7])
  v2 = regexpr('-',DAT7)
  i1 = as.numeric(substr(DAT7,1,v2[1]-1))
  i2 = as.numeric(substr(DAT7,v2[1]+1,nchar(DAT7)))
  upp1=as.numeric(S2[,c(2)])
  upp2=as.numeric(S2[,c(4)])
  low1=as.numeric(S2[,c(1)])
  low2=as.numeric(S2[,c(3)])
  kk = as.numeric(S2[,8])
  
  
  r11 = biv_dilog(low1,low2,beta_cl,kk)
  r12 = biv_dilog(upp1,low2,beta_cl,kk)
  r21 = biv_dilog(low1,upp2,beta_cl,kk)
  r22 = biv_dilog(upp1,upp2,beta_cl,kk)
  int3 = r22-r21-r12+r11
  ret1=int3
  ret2 = as.numeric(S2[,5])*log(ret1)
  lik = sum(ret2)
  if(is.nan(lik)|is.infinite(lik)){
    return(neg_ret)
  } 
  if(lambda>0){
    lik = lik-lambda/2*penalty_function(beta_mat)
  }
  return(lik)
}
#Univariate orders likelihood
symbolic_lik_orders_VS2 <- function(beta, S,X,cov,errors, lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  beta = c(beta,rep(0,length(beta)))
  BETABETA<<-beta
  vars = diag(cov)
  num_var = length(unique(S[,4]))
  num_class = 2
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  betacov = betacov2 = array(NA,dim = c(num_var,num_var,num_class))
  counts = S[,3]
  S2=S[counts>0,]
  beta_u = matrix(NA,nrow=nrow(S2),ncol=2)
  beta_c = matrix(NA,nrow=nrow(X),ncol=2)
  
  for(cc in 1:num_class){
    for(d1 in 1:num_var){
      betacov2[d1,,cc] = beta_mat[-1,cc]*cov[d1,]/vars[d1]
    }
  }
  for(cc in 1:1){
    for(vv in 1:num_var){
      b0 = beta_mat[1,cc]
      b1 = beta_mat[vv+1,cc]
      coeff = sum(betacov2[vv,-c(vv),cc])
      v1 = errors[vv,,]
      v2 = beta_mat[-c(1,vv+1),cc]%*%t(beta_mat[-c(1,vv+1),cc])
      v = v1*v2
      v = sqrt(1+sum(v)/constant^2)
      ind=S2[,4]==vv
      beta_u[ind==1,]=matrix(c(b0,b1+coeff)/v,nrow=sum(ind),ncol=2,
                             byrow=1)
      ind=X[,2]==vv
      beta_c[ind==1,]=matrix(c(b0,b1+coeff)/v,nrow=sum(ind),ncol=2,
                             byrow=1)
      
      
    }
  }
  
  r1 = exp(beta_u[,1]+beta_u[,2]*S2[,1])+1 
  r2 = exp(beta_u[,1]+beta_u[,2]*S2[,2])+1
  r3 = (log(r2)-log(r1))/(beta_u[,2])
  r41 = r3
  r42 = (S2[,2]-S2[,1])-r3
  del=S2[,2]-S2[,1]
  ret1 = rep(NA,length(r1))
  ret1[S2[,6]==1]=r41[S2[,6]==1]
  ret1[S2[,6]==2]=r42[S2[,6]==2]
  lik = sum(S2[,3]*(log(ret1)))
  
  
  r1 = exp(beta_c[,1]+beta_c[,2]*X[,1])
  r2 = 1/(1+r1)
  r2[X[,4]==1]=r2[X[,4]==1]*r1[X[,4]==1]
  r3=sum(log(r2))
  
  lik=lik+r3
  if(is.nan(lik)|is.infinite(lik)){
    return(neg_ret)
  }
  if(lambda>0){
    lik = lik-lambda/2*penalty_function(beta_mat)
  }
  return(lik)
}
#Univariate histogram likelihood, K=2 response categories
symbolic_lik_U_VS2 <- function(beta, S,cov,errors, lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  beta = c(beta,rep(0,length(beta)))
  vars = diag(cov)
  num_var = length(unique(S[,4]))
  num_class = 2
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  betacov2 = array(NA,dim = c(num_var,num_var,num_class))
  counts = S[,3]
  S2=S[counts>0,]
  beta_u = matrix(NA,nrow=nrow(S2),ncol=2)
  cc=1
  for(d1 in 1:num_var){
    betacov2[d1,,cc] = beta_mat[-1,cc]*cov[d1,]/vars[d1]
  }
  
  for(vv in 1:num_var){
    b0 = beta_mat[1,cc]
    b1 = beta_mat[vv+1,cc]
    coeff = sum(betacov2[vv,-c(vv),cc])
    v = sqrt(1+sum(errors[vv,,]*beta_mat[-c(1,vv+1),cc]%*%t(beta_mat[-c(1,vv+1),cc]))/constant^2)
    ind=S2[,4]==vv
    beta_u[ind==1,]=matrix(c(b0,b1+coeff)/v,nrow=sum(ind),ncol=2,
                           byrow=1)
  }
  
  r1 = exp(beta_u[,1]+beta_u[,2]*S2[,1])+1
  r2 = exp(beta_u[,1]+beta_u[,2]*S2[,2])+1
  r3 = (log(r2)-log(r1))/(beta_u[,2])
  r41 = r3
  r42 = (S2[,2]-S2[,1])-r3
  ret1 = rep(NA,length(r1))
  ret1[S2[,6]==1]=r41[S2[,6]==1]
  ret1[S2[,6]==2]=r42[S2[,6]==2]
  lik = sum(S2[,3]*(log(ret1)))
  if(is.nan(lik)|is.infinite(lik)){
    return(neg_ret)
  }
  if(lambda>0){
    lik = lik-lambda/2*penalty_function(beta_mat)
  }
  return(lik)
}

#Classic MLR likelihood, number of response categories >2
classic_lik <- function(beta,X,Y,lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  num_var = dim(X)[2]
  X = cbind(rep(1,dim(X)[1]),X)
  num_class = length(beta)/(num_var+1)+1
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class-1)
  beta_mat = cbind(beta_mat,rep(0,num_var+1))
  BETABETA <<- beta_mat
  denom = numer = rep(0,dim(X)[1])
  for(i in 1:num_class){
    temp_denom = exp(X%*%beta_mat[,i])
    denom = denom+temp_denom
    numer[Y==i] = temp_denom[Y==i]
  }
  ret1 = log(numer/denom)
  ret2 = sum(ret1)
  if(is.nan(ret2)){
    return(neg_ret)
  }
  if(lambda>0){
    ret2 = ret2-lambda/2*penalty_function(beta_mat)
  }
  return(ret2)
}
#Classic MLR likelihood, number of response categories =2
classic_lik2 <- function(beta,X,Y,lambda=0,weights=NULL,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  if(is.null(weights)){
    weights = rep(1/nrow(X),nrow(X))
  }
  #print(beta)
  BETABETA <<- beta
  num_var = dim(X)[2]
  X = cbind(rep(1,dim(X)[1]),X)
  num_class = 2
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class-1)
  beta_mat = cbind(beta_mat,rep(0,num_var+1))
  XY = cbind(X,Y)

  ret1 = 1/(1+exp(X%*%beta_mat[,1]))
  ret1[Y==1]=ret1[Y==1]*exp(X%*%beta_mat[,1])[Y==1]
  weightinv=1/weights
  ret2 = weightinv*log(ret1)
  ret3 = sum(ret2)
  if(is.nan(ret3)){
    return(neg_ret)
  }
  if(lambda>0){
    ret3 = ret3-lambda/2*penalty_function(beta_mat)
  }
  return(ret3)
}

#Classic OvR likelihood
classic_lik_VS <- function(beta,X,Y,lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  num_var = dim(X)[2]
  num_class = length(unique(Y))
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  BETABETA2 <<- beta_mat
  classes = sort(unique(Y))
  ret2 = 0
  for(i in 1:num_class){
    newY = rep(NA,length(Y))
    newY[Y==i] = 1
    newY[Y!=i] = 2
    temp_lik = classic_lik2(beta_mat[,i],X,newY)
    ret2 = ret2+temp_lik
  }
  if(is.nan(ret2)){
    #return(neg_ret)
  }
  if(lambda>0){
    ret2 = ret2-lambda/2*penalty_function(beta_mat)
  }
  if(ret2>maxlik){
    maxpar <<- beta_mat
    maxlik <<- ret2
  }
  return(ret2)
} 
#Classic univariate OvR likelihood
classic_lik_U_VS <- function(beta,X,cov,errors,lambda=0,print=FALSE){
  if(max(abs(beta))>beta_max){
    return(neg_ret)
  }
  num_class = length(unique(X[,3]))
  num_var = max(X[,2])
  beta_mat = matrix(beta,nrow = num_var+1,ncol = num_class)
  BETA_BETA <<- beta_mat
  vars = diag(cov)
  betacov = betacov2 = array(NA,dim = c(num_var,num_var,num_class))
  for(c in 1:num_class){
    for(d1 in 1:num_var){
      betacov2[d1,,c] = beta_mat[-1,c]*cov[d1,]/vars[d1]
    }
  }
  
  big_beta = array(NA,dim = c(2,2,num_class,num_var))
  for(cc in 1:num_class){
    for(vv in 1:num_var){
      big_beta[,2,cc,vv] = 0
      b0 = beta_mat[1,cc]
      b1 = beta_mat[vv+1,cc]
      coeff = sum(betacov2[vv,-c(vv),cc])
      v1 = errors[vv,,]
      v2 = beta_mat[-c(1,vv+1),cc]%*%t(beta_mat[-c(1,vv+1),cc])
      v = v1*v2
      v = sqrt(1+sum(v)/constant^2)
      new_b0 = b0/v
      new_b1 = (b1+coeff)/v
      big_beta[,1,cc,vv] = c(new_b0,new_b1)
    }
  }
  lik = 0
  BETABETA <<- beta_mat
  ret1 = apply(X,1,classic_wrapper_u_VS,big_beta = big_beta)
  ret2 = sum(ret1)
  if(is.nan(ret2)){
    return(neg_ret)
  }
  if(lambda>0){
    ret2 = ret2-lambda/2*penalty_function(beta_mat)
  }
  return(ret2)
}


#dilog function required for pairwise histogram likelihood
biv_dilog <- function(x1,x2,beta_cl,kk){
  t1 = -exp(beta_cl[,1]+beta_cl[,2]*x1+beta_cl[,3]*x2)
  t2 = dilog(t1)/(beta_cl[,2]*beta_cl[,3])
  t3=-t2
  t3[kk==2] = t2[kk==2]+x1[kk==2]*x2[kk==2]
  return(t3)
}

#required for classic univariate model
classic_wrapper_u_VS <- function(DAT,big_beta){
  nv=1
  i1 = DAT[2]
  denom = 0
  for(i in 1:2){
    beta_u = big_beta[,,DAT[3],i1]
    x = c(1,as.numeric(DAT[c(1)]))
    temp_denom = exp(sum(x*beta_u[,i]))
    denom = denom+temp_denom
    if(DAT[4]==i){
      numer = temp_denom
    }
  }
  ret = log(numer/denom)
  return(ret)
}

#Calculate prediction accuracies 
predict_test_data <- function(beta, DAT){
  denom = rep(0,dim(DAT)[1])
  ncla = length(unique(DAT[,dim(DAT)[2]]))
  predictions = matrix(NA, nrow = dim(DAT)[1],ncol = ncla)
  test_dat = cbind(rep(1,dim(DAT)[1]),DAT[,1:(dim(DAT)[2]-1)])
  for(i in 1:ncla){
    temp_denom = apply(test_dat,1,function(x){exp(sum(x*beta[,i]))})
    denom = denom+temp_denom
    predictions[,i] = temp_denom
  }
  for(i in 1:num_class){
    predictions[,i] = predictions[,i]/denom
  }
  max = apply(predictions,1,which.max)
  actual = DAT[,dim(DAT)[2]]
  correct = max==actual
  p = sum(correct)/length(correct)
  return(p)
}
predict_test_data_VS <- function(beta, DAT){
  denom = rep(0,dim(DAT)[1])
  ncla = length(unique(DAT[,dim(DAT)[2]]))
  predictions = matrix(NA, nrow = dim(DAT)[1],ncol = ncla)
  for(i in 1:ncla){
    a=proc.time()
    temp_denom2 = exp(cbind(1,DAT[,1:(dim(DAT)[2]-1)])%*%beta[,i])
    temp_denom2 = temp_denom2/(1+temp_denom2)
    predictions[,i] = temp_denom2
  }
  max = apply(predictions,1,which.max)
  actual = DAT[,dim(DAT)[2]]
  correct = max==actual
  p = sum(correct)/length(correct)
  return(p)
} 
predict_test_data_wrapper <- function(beta2, DAT){
  denom = rep(0,dim(DAT)[1])
  ncla = length(unique(DAT[,dim(DAT)[2]]))
  predictions = matrix(NA, nrow = dim(DAT)[1],ncol = ncla)
  test_dat = cbind(rep(1,dim(DAT)[1]),DAT[,1:(dim(DAT)[2]-1)])
  for(i in 1:ncla){
    temp_denom = apply(test_dat,1,function(x){exp(sum(x*beta2[,i]))})
    denom = denom+temp_denom
    predictions[,i] = temp_denom
  }
  for(i in 1:num_class){
    predictions[,i] = predictions[,i]/denom
  }
  max = apply(predictions,1,which.max)
  actual = DAT[,dim(DAT)[2]]
  correct = max==actual
  return(max)
}

#Find weights for subsampling methodology
find_weights <- function(X,Y,beta){
  XX = cbind(1,X)
  
  t1=1/(1+exp(XX%*%(-beta[,1])))
  t2=exp(XX%*%(-beta[,1]))*t1
  t3=rep(NA,length(t1))
  t3[Y==0]=t1[Y==0]
  t3[Y==1]=t2[Y==1]
  
  r1 = abs(Y-t3)
  sq=X^2
  r2=rowSums(sq)
  r3=sqrt(r2)
  r4 = abs((r1)*r3)
  r5=sum(r4)
  r6 = r4/r5
  return(c(r6))
}

#Histogram functions
binned <- function(dat,shigh,slow,cla){
  dat = as.numeric(dat)
  num_var = length(dat)-1
  dat2 = dat[1:num_var]
  dat3 = dat[num_var+1]
  ind2 = dat2<=shigh&dat2>=slow
  ind3 = cla==dat3
  ret = 0 
  if(sum(ind2)==num_var&ind3){
    ret = 1
  }
  return(ret)
}
sample_X <- function(dat){
  x = base::sample(1:length(dat),1,prob=dat)
  return(x)
}
histk <- function(X,Y,symbol,countmax2){
  B = dim(symbol)[1]-1
  nvar = dim(symbol)[2]
  ncla = dim(symbol)[3]
  num_obs=nrow(X)
  ret1=matrix(NA,nrow=num_obs,ncol=nvar+1)
  for(c in 1:ncla){
    indy=Y==c
    dat=X[indy,]
    nrd=sum(indy)
    WB1a=array(NA,dim=c(nrd,nvar,B))
    for(bb in 1:B){
      WB1a[,,bb]=t(symbol[1:B,,c][bb,]<=t(dat)&symbol[2:(B+1),,c][bb,]>=t(dat))
    }
    ret1[indy==1,] = cbind(apply(aperm(array(1:B,dim=c(B,nvar,nrd)),
                                       c(3,2,1))*WB1a,2,rowSums),letters[c])
    
  }
  code=ret1[,1]
  for(v in 1:nvar){
    code=paste(code,ret1[,v+1],sep='-')
  }
  counts <- as.matrix(plyr::count(code))
  final_lower = final_upper = counts
  low = symbol[1:B,,]
  high = symbol[2:(B+1),,]
  s2=matrix(unlist(strsplit(counts[,1], split="-")),nrow=nrow(counts),ncol=nvar+1,byrow=T)
  s3=cbind(matrix(as.numeric(s2[,1:nvar]),nrow=nrow(counts),ncol=nvar),match(s2[,nvar+1],letters))
  s6 = t(t(s3[,1:nvar])+B*(0:(nvar-1)))+(s3[,nvar+1]-1)*(B*nvar)
  t2=cbind(matrix(low[s6],nrow=nrow(s6),ncol=ncol(s6),byrow=F),
           matrix(high[s6],nrow=nrow(s6),ncol=ncol(s6),byrow=F),s3[,nvar+1])
  final_lower = cbind(final_lower,t2[,1:nvar])
  final_upper = cbind(final_upper,t2[,(nvar+1):(2*nvar)])
  codes=final_upper[,1]
  final_lower2 = matrix(as.numeric(final_lower[,2:(2+nvar)]),nrow=dim(final_lower)[1],ncol=nvar+1)
  final_upper2 = matrix(as.numeric(final_upper[,2:(2+nvar)]),nrow=dim(final_upper)[1],ncol=nvar+1)
  class = t2[,2*nvar+1]
  retain_classic_codes=codes[final_lower2[,1]>=countmax2]
  retain_classic_codes2=matrix(retain_classic_codes,ncol=length(retain_classic_codes),nrow=num_obs,
                               byrow=T)
  retain_classic_ind=rowSums(code==(retain_classic_codes2))!=1
  ret = list(lower=final_lower2,upper=final_upper2,class=class,
             retain_classic_ind=retain_classic_ind)
  return(ret)
} 
hist_2d <- function(X,bb,Bbuff){
  nloc = length(X[1,])
  Y=X
  counts = var_ind = array(NA, dim = c(bb,bb,nloc*(nloc-1)/2))
  bin1 = bin2 = array(NA, dim = c(bb+1,bb+1,nloc*(nloc-1)/2))
  ind = 1
  for(a1 in 1:(nloc-1)){
    for(a2 in (a1+1):nloc){
      var_ind[,,ind] = paste(a1,'-',a2,sep='')
      Yx = Y[,a1]
      Yy = Y[,a2]
      xbr = seq(min(Yx)-Bbuff,max(Yx)+Bbuff,l = bb+1)
      ybr = seq(min(Yy)-Bbuff,max(Yy)+Bbuff,l = bb+1)
      bin1[,,ind] = matrix(xbr,nrow = bb+1, ncol = bb+1,byrow=F)
      bin2[,,ind] = matrix(ybr,nrow = bb+1, ncol = bb+1,byrow=T)
      h1 = hist2(Y[,a1],Y[,a2],xbreaks=xbr,
                 ybreaks=ybr,plot=F) 
      cc = h1$z
      cc[is.na(cc)] = 0
      counts[,,ind] = cc
      
      ind = ind+1
    }
  }
  counts2 = counts[counts!=0]
  var_ind2 = var_ind[counts!=0]
  bin1l = bin1[1:bb,1:bb,][counts!=0]
  bin2l = bin2[1:bb,1:bb,][counts!=0]
  bin1h = bin1[2:(bb+1),2:(bb+1),][counts!=0]
  bin2h = bin2[2:(bb+1),2:(bb+1),][counts!=0]
  ret = cbind(bin1l,bin1h,bin2l,bin2h,counts2,var_ind2)
  return(ret)
}

rescale_function <- function(x){
  x
}

predict_test_data_classes <- function(beta, DAT){
  denom = rep(0,dim(DAT)[1])
  ncla = length(unique(DAT[,dim(DAT)[2]]))
  classes = sort(unique(DAT[,dim(DAT)[2]]))
  predictions = matrix(NA, nrow = dim(DAT)[1],ncol = ncla)
  test_dat = cbind(rep(1,dim(DAT)[1]),DAT[,1:(dim(DAT)[2]-1)])
  for(i in 1:ncla){
    temp_denom = apply(test_dat,1,function(x){exp(sum(x*beta[,i]))})
    denom = denom+temp_denom
    predictions[,i] = temp_denom
  }
  for(i in 1:num_class){
    predictions[,i] = predictions[,i]/denom
  }
  max = apply(predictions,1,which.max)
  actual = DAT[,dim(DAT)[2]]
  by_classes = matrix(NA,nrow=ncla,ncol = 3)
  colnames(by_classes) = c("N","# Correct","% Correct")
  for(i in 1:length(classes)){
    by_classes[i,1] = sum(actual==classes[i])
    by_classes[i,2] = sum(actual==classes[i]&max==classes[i])
    by_classes[i,3] = by_classes[i,2]/by_classes[i,1]
  }
  return(by_classes)
}


