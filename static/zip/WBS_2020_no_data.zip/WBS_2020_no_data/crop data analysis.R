library(glmnet)
library(caret)
#library(R2Cuba)
library(cubature)
library(plyr)
library(dplyr) 
library(xtable)
library(squash) 
library(bestNormalize)
library(nleqslv)
library(gsl)

#In practise, the CV would be done in parallel. For the manuscript, it was done using multiple servers available
#to UNSW personell (KATANA), however these won't be available for everyone. The code has been rewritten to run in series,
#however the CV will now take a long time. For convenience, the optimal CV parameters for the below configuration have 
#been saved, (non_CV_LAM), such that the manuscript results can be obtained by setting CROSS_VALIDATION=0


#Set the working directory to where all the files and data are saved
setwd("~/Dropbox/Tom - Paper 2/submission_code")
source('functions.R')
LAPTOP = 1
simulation_name = "blah"


print("Getting data")
#read in data
Data=read.table('crop_data.csv',sep=',',header=T)[,-1]
print('Correlation matrix')
print(round(cor(Data[,-8]),3))

scratch = 1
SETUP = 1

if(SETUP==1){ 
  kk=5
  NN = 2*10^kk

  #Number of bins for histograms
  actual_B = c(6,8,10,12,15,20)
  #use these if we dont want to do cross validation (CROSS_VALIDATION=1). These were the optimal parameters
  #obtained for the below setup, with the given start seed. 
  non_CV_LAM = c(2.55, 1.69, 0.572, 0.182, 0.202, 0.182)
  num_class = 7
  num_var = 7
  #number of CV folds
  n_FOLDS = 10 
   
  #Do we apply a transformation to improve the linearity assumption?
  best_normal = 1
  #1 if Cross validation is to be performed 
  CROSS_VALIDATION=0
  TOTAL_MAX_PRED <<- 0 
  #Candidate CV parameters if you wish to run the CV
  LAM_VEC=c(1,2,3,4)
  n_LAM = length(LAM_VEC)  
  ALLOW_ORDER = FALSE
  num_opt = 2
  zero_start_beta=0
  constant <<- pi/sqrt(3)
  sample_select = c(1:7)
  PRINT=FALSE
  
  #Models to be run
  U_symbolic = 1
  U_symbolic_ind = 0
  print_ind <<- 500000000
  print_ind2 <<- 200
  PREDICT_U = 0
  #optim parameters
  METHOD <<- "BFGS"
  MAXIT = 500000
  RELTOL = 1e-8
  SETUP = 1
  NUM_VAR = num_var
  NUM_CLASS = num_class
  #normalisation can be done on a subset of the data for improved computational efficiency. Setting regrbuff=1 will
  #use the entire training dataset
  regrbuff=10
  best_norm_size = NN/regrbuff
  
  if(CROSS_VALIDATION==1){
    print("LAM VECTOR")
    print(LAM_VEC)
  }
  
  CLASSIC_sub =0
  PREDICT = 1
  MFROW = c(2,2)
  N=NN
  #More optim parameters
  CONTROL = list("fnscale"=-1, maxit=MAXIT, reltol =RELTOL )
  CONTROL2 = list("fnscale"=-1, maxit=MAXIT*2, reltol =RELTOL^1.5 )
  PRED_C = 0
  VARYING <<- "B" 
  n.folds <- n_FOLDS
  equal_n = 0
  Mnrep = 2
  REP <<- 1
  Mrep=1
  KATANA=0
  ACT = 0
  job.number=0
  classes = sort(unique(Data$crop))
  classification = rep(NA,dim(Data)[1])
  #order classes by sizes for convenience
  for(i in 1:length(classes)){
    classification[Data$crop==classes[i]]=i
  }
  Data2 = cbind(Data,classification)
  CCC = rep(NA, length(unique(Data2$classification)))
  for(c in 1:length(unique(Data2$classification))){
    CCC[c]=sum(Data2$classification==c)
  }
  CCC2 = sort(CCC,decreasing=T)
  #print(Data2[1:4,1:NUM_VAR])
  num_cla = length(unique(Data2$classification))
  range = 1:dim(Data2)[1]
  
  CCC3 <<- CCC2[1:NUM_CLASS]
  select_class = NULL
  for(i in 1:NUM_CLASS){
    select_class = c(select_class,which(CCC==CCC3[i]))
  }
  old_Data = Data2
  new_Data = NULL
  for(i in 1:NUM_CLASS){
    dat = old_Data[old_Data$classification==select_class[i],]
    dat$classification = i
    new_Data = rbind(new_Data,dat)
  } 
  Data2 = new_Data
  num_var = dim(Data2)[2]-2
  par(mfrow=c(3,3)) 
  vars = apply(Data2[,1:num_var],2,var)
  var_sample = c(sample_select)[1:NUM_VAR]
  
  #set the random seed
  set.seed(50)
  
  #Transform data. Only test data is used in normalisation. 
  select_var = c(var_sample, num_var+2)
  subset = sample.int(dim(Data2)[1],NN+5,replace=F)
  subset = subset[1:NN]
  Data3 = Data2[,select_var]
  Data4 = Data3
  for(i in 1:(dim(Data3)[2]-1)){
    if(best_normal==1){
      x = bestNormalize(as.numeric(Data3[subset,i]),allow_orderNorm = FALSE,
                        quiet=TRUE,standardize = F,k=3,r=3)
      Data4[,i] = predict(x,newdata=as.numeric(Data3[,i]))
    }
    #standardise data too
    Data4[,i] = (Data4[,i]-mean(Data4[subset,i]))/sd(Data4[subset,i])
    Data3[,i] = (Data3[,i]-mean(Data3[subset,i]))/sd(Data3[subset,i])
  }
  #split up test and train data
  train.data = Data4[subset,c(1:NUM_VAR,dim(Data4)[2])]
  test.data = Data4[-c(subset),c(1:NUM_VAR,dim(Data4)[2])]
  test_N = dim(test.data)[1] 
  num_var = dim(train.data)[2]-1
  num_class = length(unique(Data2$classification))
  Xdata=train.data[,1:NUM_VAR]
  Ydata=c(train.data$classification)

  par(mfrow=c(3,3))

  #obtain covariance information
  cov_errors_u = array(NA,dim = c(num_var,num_var-1,num_var-1))
  cov_errors_cl = array(NA,dim = c(num_var,num_var,num_var-2,num_var-2))
  for(i1 in 1:num_var){
    resid = matrix(NA,nrow=nrow(Xdata), ncol = num_var)
    for(i2 in 1:num_var){
      if(i1!=i2){
        xx = as.numeric(Xdata[,i1])
        yy = as.numeric(Xdata[,i2])
        residuals=yy-((t(xx)%*%xx)^(-1))%*%t(xx)%*%yy%*%xx
        resid[,i2] = residuals
      }
    }
    cov_resid = cov(resid[,-c(i1)])
    cov_errors_u[i1,,] = cov_resid
  }
  errors_u = cov_errors_u
  
  colnames(Xdata)=NULL
  final_data = cbind(Xdata,Ydata)
  print(sort(unique(Ydata)))
  beta_buff = 1 
  start_buff = 0.3
  start_buff2 = 0.9
  PLOT=0
  FINAL_PLOT=1
  PREDICT = 1
  Bbuff = 1/N
  ptime = 3
  #set initial parameter for optim
  start_beta = rep(0,(NUM_VAR+1)*NUM_CLASS)
  start_beta2 = as.vector(start_beta)
  start_beta2 = start_beta2*0+0.001
  start_beta = head(start_beta2,-(num_var+1))*0
  

  
  hist(Ydata)
  ACT_BETA = 1
  par(mfrow=c(1,1))
   symbolic_MLE_CL = symbolic_MLE_U = array(0, dim=c(Mnrep,length(N),num_var+1,num_class))
  
 time_symbolic_U  = time_symbolic_CL = matrix(0,nrow=Mnrep,ncol=length(N))
time_symbolic_U_agg =  time_symbolic_CL_agg = matrix(0,nrow=Mnrep,ncol=length(N))
pred_symbolic_U = pred_symbolic_CL = matrix(0,nrow=Mnrep,ncol=length(N))
  
  num_bins = rep(NA, length(actual_B))
  MLE_s_u = MLE_s_cl = array(0,dim=c(length(actual_B),num_var+1,num_class))
  time_s_u = time_s_cl = rep(0,length(actual_B))
  time_s_u_agg = time_s_cl_agg = rep(0,length(actual_B))
  pred_s_u = pred_s_cl = rep(0,length(actual_B))
  
  #CV penalty function (lasso regularisation)
  penalty_function <- function(beta){
    ret = sum(abs(beta))
    return(ret)
  }
  
}

#perform CV

if(CROSS_VALIDATION==1){
  SETUP <<- 0
  pred_lam_s_u = pred_lam_s_cl  = matrix(0,nrow=n_LAM, ncol=length(actual_B))
  fold_mult =  n_FOLDS/(n_FOLDS-1)
  column_names = paste("B =",actual_B)
  row_names = paste("LAM =",LAM_VEC)
  MAX_PRED = MAX_PRED_C=0
  
  for(l in 1:length(LAM_VEC)){ 
    LAM_u= LAM_cl = rep(LAM_VEC[l],length(actual_B))
    for(n in 1:n_FOLDS){
      print(" ")
      print("NEW FOLD")
      print(paste("LAM =",LAM_VEC[l],"| FOLD =",n))
      r1 = (n-1)*N/n_FOLDS+1
      r2 = n*N/n_FOLDS
      #assign CV test and train data
      Xdata <<- train.data[-c(r1:r2),1:num_var]
      Xdata <<- matrix(unlist(Xdata),nrow=nrow(Xdata),ncol=ncol(Xdata))
      Ydata <<- train.data[-c(r1:r2),num_var+1]
      
      TEST_DATA <<- train.data[r1:r2,]
      TEST_DATA <<- matrix(unlist(TEST_DATA),nrow=nrow(TEST_DATA),ncol=ncol(TEST_DATA))

      ERRORS = 1
      num_class = NUM_CLASS
      
      #Run analysis for CV configuration
      for(b in 1:length(actual_B)){
        B <<- actual_B[b]
        if(U_symbolic==1){
          print(paste("UNI | B = ",B,sep=""))
          symbol_U = NULL
          time1 = proc.time()[ptime]
          for(i in 1:num_var){
            if(num_class>1){
              for(c in 1:num_class){
                dat = Xdata[Ydata==c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
                symbol_U = rbind(symbol_U,dat2)
                dat = Xdata[Ydata!=c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
                symbol_U = rbind(symbol_U,dat2)
              }
            }
          }
          time_s_u_agg[b] = proc.time()[ptime]-time1
          it <<- 0
          maxlik <<- -10^10
          maxpar <<- NULL
          cov=cov(Xdata)
          time1 = proc.time()[ptime]
          optS=NULL
          optS$par = start_beta2
          S=symbol_U
          errors = errors_u
          for(rr in 1:num_opt){
            optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                         lambda=LAM_u[b],cov=cov,errors = errors_u
                         ,control = CONTROL,method=METHOD,print=PRINT)
          }
          
          time_s_u[b] = (proc.time()[ptime]-time1)
          print(time_s_u[b])
          #print(optS$value)
          PAR = optS$par
          if(num_class==2){
            #PAR = c(PAR,rep(0,num_var+1))
          }
          MLE_s_u[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
          pred_beta = MLE_s_u[b,,]
          if(PREDICT==1){
            pp = predict_test_data_VS(pred_beta,TEST_DATA)
            pred_s_u[b] = pp
            print(paste(round(100*pp,2),"% Correct",sep=""))
          }
        }
        if(U_symbolic_ind==1){
          print(paste("UNI ind. | B = ",B,sep=""))
          symbol_U = NULL
          time1 = proc.time()[ptime]
          for(i in 1:num_var){
            if(num_class>1){
              for(c in 1:num_class){
                dat = Xdata[Ydata==c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
                symbol_U = rbind(symbol_U,dat2)
                dat = Xdata[Ydata!=c,i]
                if(typeof(dat)=="list"){
                  dat = as.numeric(dat[,1])
                }
                min = min(dat)-Bbuff
                max = max(dat)+Bbuff
                seq = seq(min,max,l=B+1)
                H = hist(dat,breaks = seq,plot=F)
                low = H$breaks[-(B+1)]
                high = H$breaks[-1]
                dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
                symbol_U = rbind(symbol_U,dat2)
              }
            }
          }
          time_s_cl_agg[b] = proc.time()[ptime]-time1
          it <<- 0
          maxlik <<- -10^10
          maxpar <<- NULL
          aa = proc.time()[ptime]
          cov=cov(Xdata)
          time1 = proc.time()[ptime]
          optS=NULL
          optS$par=start_beta2
          for(rr in 1:num_opt){
            optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                         lambda=LAM_u[b],cov=cov,errors = errors_u2
                         ,control = CONTROL,method=METHOD,print=TRUE)
          }
          time_s_cl[b] = proc.time()[ptime]-time1+time_s_u_agg[b]
          PAR = optS$par     
          if(num_class==2){      
            PAR = c(PAR,rep(0,num_var+1))     
          }
          MLE_s_cl[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
          pred_beta = MLE_s_cl[b,,] 
          if(PREDICT==1){
            pp = predict_test_data_VS(pred_beta,TEST_DATA)
            pred_s_cl[b] = pp
            print(paste(round(100*pp,2),"% Correct",sep=""))
          }
        }
      }
      
      #save results
      pred_lam_s_u[l,] =  pred_lam_s_u[l,] + pred_s_u/n_FOLDS
      pred_lam_s_cl[l,] =  pred_lam_s_cl[l,] + pred_s_cl/n_FOLDS
      print_table = rbind(pred_lam_s_u[l,],pred_lam_s_cl[l,])
      rownames(print_table) = c("Uni","Uni ind.")
      colnames(print_table) = column_names
      print_table2 = print_table*n_FOLDS/n
      print(paste(l,"/",length(LAM_VEC)," completed. RESULTS: LAM = ",LAM_VEC[l]," | FOLD = ",n,sep=""))
      print(print_table2)
      max_pred = max(print_table)
      
      if(max_pred>MAX_PRED){
        MAX_PRED = max_pred
        ind1 = which(print_table == max(print_table), arr.ind = TRUE)
        MAX_B = actual_B[ind1[2]]
        MAX_MOD = rownames(print_table)[ind1[1]]
        MAX_LAM = LAM_VEC[l]
      }
    }
    print(paste("Max Prediction = ",round(100*MAX_PRED,2),"%, Model = ",MAX_MOD,sep=""))
    print(paste("B = ",MAX_B,", LAM = ",MAX_LAM,sep=""))
    print("")
    #Calculate maximum P.A
    max_pred_s_cl = apply(pred_lam_s_cl,2,max)
    max_pred_s_u = apply(pred_lam_s_u,2,max)
    print_table = rbind(max_pred_s_u,max_pred_s_cl)
    column_names = paste("B =",actual_B)
    rownames(print_table) = c("Uni", "Uni Ind.")
    print('MAX PREDICTION %')
    colnames(print_table)=column_names
    print(print_table)
  }
  
  colnames(pred_lam_s_u) = column_names
  rownames(pred_lam_s_u) = row_names
  colnames(pred_lam_s_cl) = column_names
  rownames(pred_lam_s_cl) = row_names
  print("UNI")
  print(pred_lam_s_u)
  print("CL")
  print(pred_lam_s_cl)
  
  #Calculate final CV parameters 
  LAM_u  = LAM_cl  = rep(0,length(actual_B))
  for(b in 1:length(actual_B)){
    LAM_u[b] = LAM_VEC[which.max(pred_lam_s_u[,b])]*fold_mult
    LAM_cl[b] = LAM_VEC[which.max(pred_lam_s_cl[,b])]*fold_mult
  }
}

Xdata <<- train.data[,1:num_var]
Xdata <<- matrix(unlist(Xdata),nrow=nrow(Xdata),ncol=ncol(Xdata))
Ydata <<- train.data[,num_var+1]

test.data<<-matrix(unlist(test.data),nrow=nrow(test.data),ncol=ncol(test.data))
TEST_DATA <<- test.data
print_ind2 <<- print_ind

SETUP <<- 0
if(CROSS_VALIDATION==0){
  LAM_u  = LAM_cl = non_CV_LAM
} 
#We don't run the CV on the full MLR model, as this will be too computationally intensive. Instead we get an idea
#of the computational times here, and report the existing MLR results in the manuscript. 
FULL_CLASSIC=1
if(FULL_CLASSIC==1){
  print("Classic")
  time1 = proc.time()[ptime]
  it <<- 0
  maxlik <<- -10^10
  maxpar <<- NULL
  optC=NULL
  optC$par=start_beta
  for(rr in 1:num_opt){
    optC = optim(optC$par,classic_lik, X=Xdata,Y=Ydata,lambda=0,
                 print=PRINT,control = CONTROL,method=METHOD)
  }
  
  time_c_full = proc.time()[ptime]-time1
  PAR = optC$par
  temp_classic_beta_full = PAR
  MLE_c_full = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
  pred_beta = MLE_c_full
  if(PREDICT==1){
    pp = predict_test_data(pred_beta,TEST_DATA)
    pred_c_full = pp
    PRED_C <<- pred_c_full
  }
}

#Run final analysis
for(b in 1:length(actual_B)){
  B <<- actual_B[b]
  if(U_symbolic==1){
    print(paste("UNI | B = ",B,sep=""))
    symbol_U = NULL
    time1 = proc.time()[ptime]
    for(i in 1:num_var){
      if(num_class>1){
        for(c in 1:num_class){
          dat = Xdata[Ydata==c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
          symbol_U = rbind(symbol_U,dat2)
          dat = Xdata[Ydata!=c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1]) 
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
          symbol_U = rbind(symbol_U,dat2)
        }
      }
    }
    time_s_u_agg[b] = proc.time()[ptime]-time1
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    cov=cov(Xdata)
    time1 = proc.time()[ptime]
    optS=NULL
    optS$par = start_beta2
    S=symbol_U
    errors = errors_u
    for(rr in 1:num_opt){
      optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                   lambda=LAM_u[b],cov=cov,errors = errors_u
                   ,control = CONTROL,method=METHOD,print=PRINT)
    }
    
    time_s_u[b] = (proc.time()[ptime]-time1)
    print(time_s_u[b])
    #print(optS$value)
    PAR = optS$par
    if(num_class==2){
      #PAR = c(PAR,rep(0,num_var+1))
    }
    MLE_s_u[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_s_u[b,,]
    print(round(pred_beta,3))
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_s_u[b] = pp
      print(paste(round(100*pp,2),"% Correct",sep=""))
    }
  }
  if(U_symbolic_ind==1){
    print(paste("UNI ind. | B = ",B,sep=""))
    symbol_U = NULL
    time1 = proc.time()[ptime]
    for(i in 1:num_var){
      if(num_class>1){
        for(c in 1:num_class){
          dat = Xdata[Ydata==c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
          symbol_U = rbind(symbol_U,dat2)
          dat = Xdata[Ydata!=c,i]
          if(typeof(dat)=="list"){
            dat = as.numeric(dat[,1])
          }
          min = min(dat)-Bbuff
          max = max(dat)+Bbuff
          seq = seq(min,max,l=B+1)
          H = hist(dat,breaks = seq,plot=F)
          low = H$breaks[-(B+1)]
          high = H$breaks[-1]
          dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
          symbol_U = rbind(symbol_U,dat2)
        }
      }
    }
    time_s_cl_agg[b] = proc.time()[ptime]-time1
    it <<- 0
    maxlik <<- -10^10
    maxpar <<- NULL
    aa = proc.time()[ptime]
    cov=cov(Xdata)
    time1 = proc.time()[ptime]
    optS=NULL
    optS$par=start_beta2
    for(rr in 1:num_opt){
      optS = optim(optS$par,symbolic_lik_U_VS, S=symbol_U,
                   lambda=LAM_u[b],cov=cov,errors = errors_u2
                   ,control = CONTROL,method=METHOD,print=TRUE)
    }
    time_s_cl[b] = proc.time()[ptime]-time1+time_s_u_agg[b]
    PAR = optS$par     
    if(num_class==2){      
      PAR = c(PAR,rep(0,num_var+1))     
    }
    MLE_s_cl[b,,] = matrix(PAR,nrow = num_var+1,ncol = num_class)
    pred_beta = MLE_s_cl[b,,] 
    if(PREDICT==1){
      pp = predict_test_data_VS(pred_beta,TEST_DATA)
      pred_s_cl[b] = pp
      print(paste(round(100*pp,2),"% Correct",sep=""))
    }
  }
}



