library(glmnet)
#library(R2Cuba)
library(cubature)
library(plyr)
library(squash) 
library(nleqslv)  
library(mnormt)
#library(R2Cuba)
library(gsl)
library(sn)
library(bestNormalize)


#Change this directory to the code/data location
setwd("~/Dropbox/Tom - Paper 2/submission_code")
source('functions.R')

#START_SEED is the random seed. Change this for different simulated parameter values,
#data and covariance matrix.
START_SEED = 66878
simulation_name = "MODEL1"
SET_PARAMETERS = 1 
VARYING <<- "B"
job.number = 1 
# Number of replications
Mnrep = 100 

if(SET_PARAMETERS==1){
  uniform_sampling = 0
  beta_buff = 0.0001
  quick_test = 0
  set.seed(START_SEED) 
  
  #These are the main parameters of the simulation
  N = seq(5000,95000,by=15000)
  DENSITY = "SKEWNORMAL"
  num_class = 2
  num_var = 8
  B = 15
  
  #Subsample size for subsampling methodology
  num_sub = 1000
  num_sub2 = 1000
  
  #These variables determine which models are run
  U_symbolic = 1
  naive_model = 1
  U_symbolic_ind = 1
  CL_symbolic = 0
  CLASSIC = 1
  CLASSIC_sub = 1
  #Set this variable to be some tiny number for independent covariates
  CORRELATION_BUFF = 0.75
  maxskew = 7
  unif_range = 2
  zero_start_beta = 0
  start_buff = 0.5
  START_BETA = 0.5
  constant <<- pi/sqrt(3)
  print_ind <<- 20000000
  METHOD <<- "BFGS" 
  MAXIT = 1000
  RELTOL = 1e-8
  ptime = 1
  num_opt = 2
  SAVE_RESULTS = 0
  SETUP = 1
  NUM_VAR = num_var
  LAM = 0
  LAM = LAM_u = LAM_cl = LAM_U_ind= rep(LAM,length(N))
  NUM_CLASS = num_class
}

model_ind = c(CLASSIC,CLASSIC_sub,U_symbolic,U_symbolic_ind,CL_symbolic,naive_model)
ACT=1
PLOT=0
FINAL_PLOT=1
PREDICT = 1
actual_beta_vec = rep(0.5,num_var+1)*runif(num_var+1,1-beta_buff,1+beta_buff)
actual_beta_vec = runif((num_var+1),-1,1)
actual_beta = actual_beta_vec
beta_matrix = matrix(actual_beta,nrow = num_var+1,ncol = num_class-1)
beta_matrix = cbind(beta_matrix,rep(0,num_var+1))
PRINT=1

#simulate covariance matrix
varcov = matrix(1,nrow=num_var,ncol=num_var)
pdef = 0
while(pdef==0){
  for(i in 1:(num_var-1)){
    for(j in (i+1):num_var){
      varcov[i,j] = varcov[j,i] = runif(1,0,CORRELATION_BUFF)
    }
  }
  eig = eigen(varcov,symmetric=TRUE)
  if(sum(eig$values>0)==num_var){
    pdef = 1
  }
}
skew_param = runif(num_var,-maxskew,maxskew)

ACT_BETA <<- beta_matrix
print(paste("ACTUAL BETA"))
print(beta_matrix)
#Create tables to store results
classic_MLE_FULL = classic_MLE = classic_MLE_sub = symbolic_MLE_mix = symbolic_MLE_CL = 
  symbolic_MLE_U=symbolic_MLE_naive = symbolic_MLE_U_ind = array(0, dim=c(Mnrep,length(N),num_var+1,num_class))

time_classic = time_classic_sub_agg= time_classic_FULL =time_classic_U = time_classic_CL = pred_classic_FULL=
  pred_classic=pred_classic_U=pred_classic_CL =time_classic_sub=pred_classic_sub=
  time_symbolic_mix =time_classic_agg = time_symbolic_U=time_symbolic_naive = time_symbolic_U_ind = time_symbolic_CL = matrix(0,nrow=Mnrep,ncol=length(N))
time_symbolic_mix_agg=time_symbolic_naive_agg = time_symbolic_U_agg = time_symbolic_U_ind_agg = time_symbolic_CL_agg = matrix(0,nrow=Mnrep,ncol=length(N))
pred_symbolic_mix = pred_symbolic_U=pred_symbolic_naive = pred_symbolic_U_ind = pred_symbolic_CL = matrix(0,nrow=Mnrep,ncol=length(N))



for(Mrep in 1:Mnrep){
  REP <<- Mrep
  
  ERRORS = 1
  print(paste('Mrep =',Mrep))
  #Simulate data
  if(SETUP==1){
    set.seed(job.number*Mnrep+Mrep)
    if(DENSITY=="NORMAL"){
      if(CORRELATION_BUFF<1e-5){
        Xdata = matrix(rnorm(num_var*max(N),0,1),nrow=max(N),ncol=num_var)
        test_Xdata = matrix(rnorm(num_var*max(N),0,1),nrow=max(N),ncol=num_var)
      }
      if(CORRELATION_BUFF>=1e-5){
        Xdata = rmnorm(max(N),rep(0,num_var),varcov)
        test_Xdata = rmnorm(max(N),rep(0,num_var),varcov)
      }
    }
    if(DENSITY=="SKEWNORMAL"){
      Xdata = rmsn(max(N),rep(0,num_var),Omega=varcov,alpha=skew_param)
      test_Xdata = rmsn(max(N),rep(0,num_var),Omega=varcov,alpha=skew_param)
    }
    if(DENSITY=="UNIFORM"){
      Xdata = matrix(runif(num_var*max(N),-unif_range,unif_range),nrow=max(N),ncol=num_var)
      test_Xdata = matrix(runif(num_var*max(N),-unif_range,unif_range),nrow=max(N),ncol=num_var)
    }
    if(DENSITY=="EXP"){
      Xdata = matrix(rexp(num_var*max(N),2),nrow=max(N),ncol=num_var)
      test_Xdata = matrix(rexp(num_var*max(N),2),nrow=max(N),ncol=num_var)
    }
    for(nn in 1:num_var){
      Xdata[,nn] = (Xdata[,nn]-mean(Xdata[,nn]))/sd(Xdata[,nn])
      test_Xdata[,nn] = (test_Xdata[,nn]-mean(Xdata[,nn]))/sd(Xdata[,nn])
    }
    print(paste("Cov(X)"))
    print(round(cov(Xdata),2))
    XX = cbind(rep(1,max(N)),Xdata)
    test_XX = cbind(rep(1,max(N)),test_Xdata)
    predictions = test_predictions = matrix(NA, nrow = max(N),ncol = num_class)
    denom = test_denom = rep(0,max(N))
    for(i in 1:num_class){
      temp_denom = apply(XX,1,function(x){exp(sum(x*beta_matrix[,i]))})
      denom = denom+temp_denom
      predictions[,i] = temp_denom
      temp_denom = apply(test_XX,1,function(x){exp(sum(x*beta_matrix[,i]))})
      test_denom = denom+temp_denom
      test_predictions[,i] = temp_denom
    }
    for(i in 1:num_class){
      predictions[,i] = predictions[,i]/denom
      test_predictions[,i] = test_predictions[,i]/test_denom
    }
    Ydata = apply(predictions,1,sample_X)
    test_Ydata = apply(test_predictions,1,sample_X)
    
    if(Mrep==1){
      par(mfrow=c(1,1))
      hist(Ydata)
    }
    if(length(unique(Ydata))!=num_class){
      stop()
    }
    
    start_beta = actual_beta*runif(num_var+1,1-start_buff,1+start_buff)
    #start_beta = actual_beta*start_buff
    if(zero_start_beta==1){
      start_beta=start_beta*0+0.000001
    }
    TEST_DATA = cbind(test_XX[,-1],test_Ydata)
    CONTROL = list("fnscale"=-1, maxit=MAXIT, reltol =RELTOL )
    PRED_C = 0
    
    COMBS <<- NULL
    num_bins = rep(NA, length(N))
    MLE_c = MLE_c_sub = MLE_c_full = MLE_s = MLE_s_u=MLE_s_naive = MLE_s_u_ind = MLE_s_cl = array(0,dim=c(length(N),num_var+1,num_class))
    time_c = time_c_agg = time_c_sub = time_c_sub_agg = time_c_full = time_s = time_s_u=time_s_naive=time_s_u_ind = time_s_cl = rep(0,length(N))
    time_s_agg =time_s_naive_agg= time_s_u_agg=time_s_u_ind_agg = time_s_cl_agg = rep(0,length(N))
    pred_c = pred_c_full = pred_c_sub = pred_s = pred_s_u=pred_s_naive=pred_s_u_ind = pred_s_cl = rep(0,length(N))
    
    vars = rep(NA,dim(Xdata)[2])
    for(i in 1:num_var){
      vars[i] = var(Xdata[,i])
    }
  }
  #Obtain covariance information
  if(ERRORS==1){
    errors_u = array(NA,dim = c(num_var,num_var))
    cov_errors_u = cov_errors_ui=array(NA,dim = c(num_var,num_var-1,num_var-1))
    cov_errors_cl = array(NA,dim = c(num_var,num_var,num_var-2,num_var-2))
    for(i1 in 1:num_var){
      print(i1)
      resid = matrix(NA,nrow=dim(Xdata)[1], ncol = num_var)
      for(i2 in 1:num_var){
        if(i1!=i2){
          xx = as.numeric(Xdata[,i1])
          yy = as.numeric(Xdata[,i2])
          m = lm(yy~xx)
          errors_u[i1,i2] = sd(m$residuals)
          resid[,i2] = m$residuals
        }
      }
      cov_resid = cov(resid[,-c(i1)])
      cov_errors_u[i1,,] = cov_resid
      cov_errors_ui[i1,,] = 0
      diag(cov_errors_ui[i1,,]) = 1
    }
    if(CL_symbolic==1){
      errors_cl = array(NA,dim=c(num_var,num_var,num_var))
      bbb_cl = array(NA,dim = c(num_var,2,num_var,num_var))
      for(i1 in 1:(num_var-1)){
        for(i2 in (i1+1):num_var){
          resid = matrix(NA,nrow=dim(Xdata)[1], ncol = num_var)
          for(i3 in 1:num_var){
            if(i1!=i3&i2!=i3){
              xx = cbind(Xdata[,c(i1)],Xdata[,c(i2)])
              yy = Xdata[,i3]
              m = lm(yy~xx)
              errors_cl[i1,i2,i3] = sd(m$residuals)
              bbb_cl[i3,,i1,i2] = m$coefficients[-c(1)]
              resid[,i3] = m$residuals
            }
          }
          cov_resid = cov(resid[,-c(i1,i2)])
          cov_errors_cl[i1,i2,,] = cov_resid
        }
      }
      errors_cl = cov_errors_cl
    }
    errors_u = cov_errors_u
    errors_ui = cov_errors_ui
  }
  
  old_Xdata = Xdata
  old_Ydata = Ydata
  Ydata2 = Ydata
  Ydata2[Ydata2==1]=0
  Ydata2[Ydata2==2]=1
  old_Ydata2 = Ydata2
  for(b in 1:length(N)){
    NN <<- N[b]
    print(paste("N =",NN))
    Xdata = old_Xdata[1:N[b],]
    Ydata = old_Ydata[1:N[b]]
    Ydata2 = old_Ydata2[1:N[b]]
    Bbuff = 1/N[b]
    #classic model
    if(CLASSIC==1){
      time1 = proc.time()[ptime]
      it <<- 2
      maxlik <<- -10^10
      print("Classic Full")
      maxpar <<- NULL
      optC = NULL
      optC$par = start_beta
      for(rr in 1:num_opt){
        optC = optim(optC$par,classic_lik2, X=Xdata,Y=Ydata,lambda=LAM[b],
                     print=PRINT,control = CONTROL,method=METHOD)
      }
      
      PAR = optC$par
      time_c[b] = proc.time()[ptime]-time1
      time_c_agg[b]=0
      MLE_c[b,,] = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_c[b,,]
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_c[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
    #Wang et al subsampling methodology
    if(CLASSIC_sub==1){
      print("Classic Sub Sample")
      it <<- 2
      maxlik <<- -10^10
      maxpar <<- NULL
      samp1 = sample(1:NN,num_sub)
      time1 = proc.time()[ptime]
      optC = optim(start_beta,classic_lik2, X=Xdata[samp1,],Y=Ydata[samp1],lambda=LAM[b],
                   print=PRINT,control = CONTROL,method=METHOD)
      sub_par = optC$par
      SUB_MAT = cbind(matrix(sub_par,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      weights = find_weights(Xdata,Ydata2,SUB_MAT)
      if(uniform_sampling==1){
        weights = rep(1,length(weights))
        weights = weights/sum(weights)
      }
      samp2 = sample(1:NN,num_sub2,prob=weights)
      samp = c(samp1,samp2)
      weights2 = c(rep(1/NN,length(samp1)),weights[samp2])
      if(uniform_sampling==1){
        samp = sample(1:NN,num_sub+num_sub2)
        weights2=rep(1,length(samp))
        weights2 = weights2/sum(weights2)
      }
      time_c_sub_agg[b] = proc.time()[ptime]-time1
      time2 = proc.time()[ptime]
      optC = NULL
      optC$par = start_beta
      for(rr in 1:num_opt){
        optC = optim( optC$par,classic_lik2, X=Xdata[samp,],Y=Ydata[samp],lambda=LAM[b],
                      print=PRINT,control = CONTROL,weights=weights2,method=METHOD)
      }
      
      PAR = optC$par
      
      time_c_sub[b]  = proc.time()[ptime]-time2
      MLE_c_sub[b,,] = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_c_sub[b,,]
      if(PREDICT==1){
        pp = predict_test_data(pred_beta,TEST_DATA)
        pred_c_sub[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
    #Univariate histogram model with covariate information
    if(U_symbolic==1){
      print(paste("UNI | B = ",B,sep=""))
      symbol_U = NULL
      a = proc.time()[ptime]
      for(i in 1:num_var){
        if(num_class==2){
          for(c in 1:(num_class-1)){
            dat = Xdata[Ydata==c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
            symbol_U = rbind(symbol_U,dat2)
            dat = Xdata[Ydata!=c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
            symbol_U = rbind(symbol_U,dat2)
          }
        }
      }
      time_s_u_agg[b] = proc.time()[ptime]-a
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      time1 = proc.time()[ptime]
      optS = NULL
      optS$par = start_beta
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_U_VS2, S=symbol_U,
                     lambda=LAM_u[b],cov=cov(Xdata),errors = errors_u
                     ,control = CONTROL,method=METHOD,print=TRUE)
      }
      
      time_s_u[b] = proc.time()[ptime]-time1
      PAR = optS$par
      MLE_s_u[b,,] =cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_s_u[b,,]
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_u[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
    #Univariate histogram model assuming covariate independence
    if(U_symbolic_ind==1){
      print(paste("UNI ind. | B = ",B,sep=""))
      symbol_U = NULL
      a = proc.time()[ptime]
      for(i in 1:num_var){
        if(num_class==2){
          for(c in 1:(num_class-1)){
            dat = Xdata[Ydata==c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
            symbol_U = rbind(symbol_U,dat2)
            dat = Xdata[Ydata!=c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
            symbol_U = rbind(symbol_U,dat2)
          }
        }
      }
      time_s_u_ind_agg[b] = proc.time()[ptime]-a
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      time1 = proc.time()[ptime]
      covcov=cov(Xdata)*0
      diag(covcov)=diag(Xdata)
      optS = NULL
      optS$par = start_beta
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_U_VS2, S=symbol_U,
                     lambda=LAM_u[b],cov=covcov,errors = errors_ui
                     ,control = CONTROL,method=METHOD,print=TRUE)
      }
      time_s_u_ind[b] = proc.time()[ptime]-time1
      PAR = optS$par
      MLE_s_u_ind[b,,] =cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_s_u_ind[b,,]
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_u_ind[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
    #Pairwise histogram model.
    if(CL_symbolic==1){
      print(paste("CL | B = ",B,sep=""))
      symbol_CL = NULL
      a = proc.time()[ptime]
      for(i in 1:(num_var-1)){
        for(j in (i+1):num_var){
          if(num_class==2){
            for(c in 1:(num_class-1)){
              dat = Xdata[Ydata==c,c(i,j)]
              tempS = hist_2d(dat,B,Bbuff)[,1:5]
              tempS = cbind(tempS,rep(c,dim(tempS)[1]),rep(paste(i,'-',j,sep=''),dim(tempS)[1]),1)
              symbol_CL = rbind(symbol_CL,tempS)
              dat = Xdata[Ydata!=c,c(i,j)]
              tempS = hist_2d(dat,B,Bbuff)[,1:5]
              tempS = cbind(tempS,rep(c,dim(tempS)[1]),rep(paste(i,'-',j,sep=''),dim(tempS)[1]),2)
              symbol_CL = rbind(symbol_CL,tempS)
            }
          }
        }
      }
      time_s_cl_agg[b] = proc.time()[ptime]-a
      S=symbol_CL
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      time1 = proc.time()[ptime]
      
      optS = NULL
      optS$par = start_beta
      cov=cov(Xdata)
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_CL_VS, S=symbol_CL,lambda=LAM_cl[b],
                     cov=cov,errors = errors_cl,bbb=bbb_cl
                     ,control = CONTROL,method=METHOD)
      }
      time_s_cl[b] = proc.time()[ptime]-time1
      PAR = optS$par
      MLE_s_cl[b,,] = cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_s_cl[b,,] 
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_cl[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
    #Naive CL model
    if(naive_model==1){
      print(paste("Naive model | B = ",B,sep=""))
      symbol_U = NULL
      a = proc.time()[ptime]
      for(i in 1:num_var){
        if(num_class==2){
          for(c in 1:(num_class-1)){
            dat = Xdata[Ydata==c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),1)
            symbol_U = rbind(symbol_U,dat2)
            dat = Xdata[Ydata!=c,i]
            if(typeof(dat)=="list"){
              dat = as.numeric(dat[,1])
            }
            min = min(dat)-Bbuff
            max = max(dat)+Bbuff
            seq = seq(min,max,l=B+1)
            H = hist(dat,breaks = seq,plot=F)
            low = H$breaks[-(B+1)]
            high = H$breaks[-1]
            dat2 = cbind(low,high,H$counts,rep(i,length(low)),rep(c,length(low)),2)
            symbol_U = rbind(symbol_U,dat2)
          }
        }
      }
      time_s_naive_agg[b] = proc.time()[ptime]-a
      it <<- 0
      maxlik <<- -10^10
      maxpar <<- NULL
      time1 = proc.time()[ptime]
      optS = NULL
      optS$par = start_beta
      covcov=cov(Xdata)*0
      diag(covcov)=diag(Xdata)
      for(rr in 1:num_opt){
        optS = optim(optS$par,symbolic_lik_U_VS3, S=symbol_U,
                     lambda=LAM_u[b],cov=covcov,errors = errors_u*0
                     ,control = CONTROL,method=METHOD,print=TRUE)
      }
      
      time_s_naive[b] = proc.time()[ptime]-time1
      PAR = optS$par
      MLE_s_naive[b,,] =cbind(matrix(PAR,nrow = num_var+1,ncol = num_class-1),rep(0,num_var+1))
      pred_beta = MLE_s_naive[b,,]
      if(PREDICT==1){
        pp = predict_test_data_VS(pred_beta,TEST_DATA)
        pred_s_naive[b] = pp
        print(paste(round(100*pp,2),"% Correct",sep=""))
      }
    }
  }
  par(mfrow=c(3,4))
  if(CLASSIC==1){
    classic_MLE[Mrep,,,] = MLE_c
    time_classic[Mrep,] = time_c
    time_classic_agg[Mrep,] = time_c_agg
    if(PREDICT==1){
      pred_classic[Mrep,] = pred_c
    }
  }
  if(CLASSIC_sub==1){
    classic_MLE_sub[Mrep,,,] = MLE_c_sub
    time_classic_sub[Mrep,] = time_c_sub
    time_classic_sub_agg[Mrep,] = time_c_sub_agg
    if(PREDICT==1){
      pred_classic_sub[Mrep,] = pred_c_sub
    }
  } 
  if(U_symbolic==1){
    symbolic_MLE_U[Mrep,,,] = MLE_s_u
    time_symbolic_U[Mrep,] = time_s_u
    time_symbolic_U_agg[Mrep,] = time_s_u_agg
    if(PREDICT==1){
      pred_symbolic_U[Mrep,] = pred_s_u
    }
    symbolic_MLE_naive[Mrep,,,] = MLE_s_naive
    time_symbolic_naive[Mrep,] = time_s_naive
    time_symbolic_naive_agg[Mrep,] = time_s_naive_agg
    if(PREDICT==1){
      pred_symbolic_naive[Mrep,] = pred_s_naive
    }
  }
  if(U_symbolic_ind==1){
    symbolic_MLE_U_ind[Mrep,,,] = MLE_s_u_ind
    time_symbolic_U_ind[Mrep,] = time_s_u_ind
    time_symbolic_U_ind_agg[Mrep,] = time_s_u_ind_agg
    if(PREDICT==1){
      pred_symbolic_U_ind[Mrep,] = pred_s_u_ind
    }
  }
  if(CL_symbolic==1){
    symbolic_MLE_CL[Mrep,,,] = MLE_s_cl
    time_symbolic_CL[Mrep,] = time_s_cl
    time_symbolic_CL_agg[Mrep,] = time_s_cl_agg
    if(PREDICT==1){
      pred_symbolic_CL[Mrep,] = pred_s_cl
    }
  }
  source('sim42_plot.R')
}

