b1=1
b2=length(N)
CEXBUFF=1.5
LOGSCALE = 0
NAMES = c("Classic","Subsample","CL Uni Histogram OvR","CL Uni Histogram OvR Independent",
          "CL Pairwise Histogram OvR ","CL Uni Histogram Naive")
COLOURS = c("black","black","darkgrey", "darkgrey","black","darkgrey")
plot_LTY = c(1,2,1,2,3,3)
plot_param = sort(sample(1:nrow(beta_matrix),4))
PLOT_PARAMS = 1
PLOT_TIMES = 1
PLOT_PREDICTIONS = 1
PLOT_MSE = 1
leg_title = paste("Legend, # Rep =",Mrep)
#leg_title = "Legend"
leg_colours = c(COLOURS[which(model_ind==1)])
leg_names = c(NAMES[which(model_ind==1)])
leg_lty = c(plot_LTY[which(model_ind==1)])


LTY = 1
LWD = 3
Mrep_ind = Mrep

if(Mrep_ind==1){
  mean_classic_MLE = classic_MLE[1:Mrep_ind,,,]
  mean_classic_MLE_sub = classic_MLE_sub[1:Mrep_ind,,,]
  mean_symbolic_MLE_CL = symbolic_MLE_CL[1:Mrep_ind,,,]
  mean_symbolic_MLE_U_ind = symbolic_MLE_U_ind[1:Mrep_ind,,,] 
  mean_symbolic_MLE_U = symbolic_MLE_U[1:Mrep_ind,,,]
  mean_symbolic_MLE_naive = symbolic_MLE_naive[1:Mrep_ind,,,]
  
  mean_time_classic = time_classic[1:Mrep_ind,]
  mean_time_classic_sub = time_classic_sub[1:Mrep_ind,]
  mean_time_symbolic_CL = time_symbolic_CL[1:Mrep_ind,]
  mean_time_symbolic_U_ind = time_symbolic_U_ind[1:Mrep_ind,]
  mean_time_symbolic_U = time_symbolic_U[1:Mrep_ind,]
  mean_time_symbolic_naive = time_symbolic_naive[1:Mrep_ind,]
  mean_time_classic_agg = time_classic_agg[1:Mrep_ind,]
  mean_time_classic_sub_agg = time_classic_sub_agg[1:Mrep_ind,]
  mean_time_symbolic_CL_agg = time_symbolic_CL_agg[1:Mrep_ind,]
  mean_time_symbolic_U_ind_agg = time_symbolic_U_ind_agg[1:Mrep_ind,]
  mean_time_symbolic_U_agg = time_symbolic_U_agg[1:Mrep_ind,]
  mean_time_symbolic_naive_agg = time_symbolic_naive_agg[1:Mrep_ind,]
  
  mean_pred_classic = pred_classic[1:Mrep_ind,]
  mean_pred_classic_sub = pred_classic_sub[1:Mrep_ind,]
  mean_pred_symbolic_CL = pred_symbolic_CL[1:Mrep_ind,]
  mean_pred_symbolic_U_ind = pred_symbolic_U_ind[1:Mrep_ind,]
  mean_pred_symbolic_U = pred_symbolic_U[1:Mrep_ind,]
  mean_pred_symbolic_naive = pred_symbolic_naive[1:Mrep_ind,]
}
if(Mrep_ind>1){
  mean_classic_MLE = apply(classic_MLE[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_classic_MLE_sub = apply(classic_MLE_sub[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_CL = apply(symbolic_MLE_CL[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_U_ind = apply(symbolic_MLE_U_ind[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_U = apply(symbolic_MLE_U[1:Mrep_ind,,,],c(2,3,4),mean)
  mean_symbolic_MLE_naive = apply(symbolic_MLE_naive[1:Mrep_ind,,,],c(2,3,4),mean)
  
  mean_time_classic =apply(time_classic[1:Mrep_ind,],2,mean)
  mean_time_classic_sub = apply(time_classic_sub[1:Mrep_ind,],2,mean)
  mean_time_symbolic_CL = apply(time_symbolic_CL[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_ind = apply(time_symbolic_U_ind[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U = apply(time_symbolic_U[1:Mrep_ind,],2,mean)
  mean_time_symbolic_naive = apply(time_symbolic_naive[1:Mrep_ind,],2,mean)
  mean_time_classic_agg =apply(time_classic_agg[1:Mrep_ind,],2,mean)
  mean_time_classic_sub_agg = apply(time_classic_sub_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_CL_agg = apply(time_symbolic_CL_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_ind_agg = apply(time_symbolic_U_ind_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_U_agg = apply(time_symbolic_U_agg[1:Mrep_ind,],2,mean)
  mean_time_symbolic_naive_agg = apply(time_symbolic_naive_agg[1:Mrep_ind,],2,mean)
  
  mean_pred_classic = apply(pred_classic[1:Mrep_ind,],2,mean)
  mean_pred_classic_sub = apply(pred_classic_sub[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_CL = apply(pred_symbolic_CL[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_U_ind = apply(pred_symbolic_U_ind[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_U = apply(pred_symbolic_U[1:Mrep_ind,],2,mean)
  mean_pred_symbolic_naive = apply(pred_symbolic_naive[1:Mrep_ind,],2,mean)
}

MEAN_PRED = rbind(mean_pred_classic,mean_pred_classic_sub,mean_pred_symbolic_U,
                  mean_pred_symbolic_U_ind,mean_pred_symbolic_CL,mean_pred_symbolic_naive)
MEAN_TIME_OPT = rbind(mean_time_classic,mean_time_classic_sub,mean_time_symbolic_U,
                      mean_time_symbolic_U_ind,mean_time_symbolic_CL,mean_time_symbolic_naive)
MEAN_TIME_AGG = rbind(mean_time_classic_agg,mean_time_classic_sub_agg,mean_time_symbolic_U_agg,
                      mean_time_symbolic_U_ind_agg,mean_time_symbolic_CL_agg,mean_time_symbolic_naive_agg)

if(PLOT_PARAMS==1){
  par(mfrow=c(2,2))
  it = 1
  for(j in 1:(num_class-1)){
    for(i in 1:(num_var+1)){
      if(sum(plot_param==it)==1){
        plot_ind = 0
        #MAIN = paste("Param",j,",",i,"mean",sep="")
        MAIN2 = bquote(beta[.(i-1)])
        print(i)
        PARAM_PLOT = rbind(mean_classic_MLE[,i,j],mean_classic_MLE_sub[,i,j],mean_symbolic_MLE_U[,i,j],
                           mean_symbolic_MLE_U_ind[,i,j],mean_symbolic_MLE_CL[,i,j],mean_symbolic_MLE_naive[,i,j])
        lim = c(as.vector(PARAM_PLOT[,b1:b2]))
        lim = lim[!is.nan(lim)]
        lim = lim[!is.infinite(lim)]
        lim = lim[lim!=0]
        for(pl in 1:dim(PARAM_PLOT)[1]){
          if(plot_ind==0&model_ind[pl]==1){
            plot(N[b1:b2],PARAM_PLOT[pl,b1:b2],type="l",col=COLOURS[pl],lty=plot_LTY[pl],
                 ylim=c(min(lim),max(lim)),main=MAIN2,lwd=LWD,
                 xlab="N",ylab="MLE")
            plot_ind = 1
          }
          if(plot_ind==1&model_ind[pl]==1){
            lines(N[b1:b2],PARAM_PLOT[pl,b1:b2],type="l",col=COLOURS[pl],lty=plot_LTY[pl],
                  lwd=LWD)
          }
        }
      }
      it = it+1
      
      
    }
  }
}
if(PLOT_MSE==1){
  par(mfrow=c(1,1))
  bmat2 = matrix(beta_matrix[,1],nrow=nrow(mean_classic_MLE[,,1]),
                 ncol=ncol(mean_classic_MLE[,,1]),byrow=T)
  MSE_classic = apply((mean_classic_MLE[,,1]-bmat2)^2,1,mean)
  MSE_classic_sub = apply((mean_classic_MLE_sub[,,1]-bmat2)^2,1,mean)
  MSE_symbolic_U = apply((mean_symbolic_MLE_U[,,1]-bmat2)^2,1,mean)
  MSE_symbolic_U_ind = apply((mean_symbolic_MLE_U_ind[,,1]-bmat2)^2,1,mean)
  MSE_symbolic_CL = apply((mean_symbolic_MLE_CL[,,1]-bmat2)^2,1,mean)
  MSE_symbolic_naive = apply((mean_symbolic_MLE_naive[,,1]-bmat2)^2,1,mean)
  plot_ind = 0
  MAIN = "Mean Mean Squared Error"
  ylab="Mean MSE"
  
  PARAM_PLOT = rbind(MSE_classic,MSE_classic_sub,MSE_symbolic_U,MSE_symbolic_U_ind,MSE_symbolic_CL,MSE_symbolic_naive)
  if(LOGSCALE==1){
    MAIN = "Log Mean Mean Squared Error"
    MAIN = NULL
    ylab="Log Mean MSE"
    PARAM_PLOT=log(PARAM_PLOT)
  }
  lim = c(as.vector(PARAM_PLOT[model_ind==1,b1:b2]))
  for(pl in 1:dim(PARAM_PLOT)[1]){
    if(plot_ind==0&model_ind[pl]==1){
      plot(N[b1:b2],PARAM_PLOT[pl,b1:b2],type="l",col=COLOURS[pl],lty=plot_LTY[pl],
           ylim=c(min(lim),max(lim)),main=MAIN,lwd=LWD,
           xlab="N",ylab=ylab,cex.lab=CEXBUFF,cex.axis=CEXBUFF)
      plot_ind = 1
    }
    if(plot_ind==1&model_ind[pl]==1){
      lines(N[b1:b2],PARAM_PLOT[pl,b1:b2],type="l",col=COLOURS[pl],lty=plot_LTY[pl],
            lwd=LWD)
    }
  }
  abline(h=0)
  #legend("topright",title=leg_title,col=leg_colours,legend=leg_names,lty=leg_lty,lwd=LWD,cex=1)
}
if(PLOT_TIMES==1){
  par(mfrow=c(1,1))
  
  #OPTIMISATION TIME
  plot_ind = 0
  lim=c(as.vector(MEAN_TIME_OPT[,b1:b2]))
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  for(i in 1:(length(model_ind))){
    if(plot_ind==0&model_ind[i]==1){
      plot(N[b1:b2],MEAN_TIME_OPT[i,b1:b2],type="l",col=COLOURS[i],lty=plot_LTY[i],
           ylim=c(min(lim),max(lim)),main="Optimisation times",xlab="N",lwd=LWD,
           ylab="time (s)")
      plot_ind = 1
    }
    if(plot_ind==1&model_ind[i]==1){
      lines(N[b1:b2],(MEAN_TIME_OPT[i,b1:b2]),type="l",col=COLOURS[i],lty=plot_LTY[i],lwd=LWD)
    }
  }
  
  #AGGREGATION TIME
  plot_ind = 0
  lim=c(as.vector(MEAN_TIME_AGG[,b1:b2]))
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  for(i in 1:(length(model_ind))){
    if(plot_ind==0&model_ind[i]==1){
      plot(N[b1:b2],MEAN_TIME_AGG[i,b1:b2],type="l",col=COLOURS[i],lty=plot_LTY[i],
           ylim=c(min(lim),max(lim)),main="Aggregation times",xlab="N",lwd=LWD,
           ylab="time (s)")
      plot_ind = 1
    }
    if(plot_ind==1&model_ind[i]==1){
      lines(N[b1:b2],(MEAN_TIME_AGG[i,b1:b2]),type="l",col=COLOURS[i],lty=plot_LTY[i],lwd=LWD)
    }
  }
  
  #TOTAL TIME
  plot_ind = 0
  MEAN_TIME = MEAN_TIME_AGG+MEAN_TIME_OPT
  print(MEAN_TIME)
  lim=c(as.vector(MEAN_TIME[-c(1,5),b1:b2]))
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  for(i in 1:(length(model_ind))){
    if(plot_ind==0&model_ind[i]==1){
      plot(N[b1:b2],MEAN_TIME[i,b1:b2],type="l",col=COLOURS[i],lty=plot_LTY[i],
           ylim=c(min(lim),max(lim)),main=NULL,xlab="N",lwd=LWD,
           ylab="Time (s)",cex.lab=CEXBUFF,cex.axis=CEXBUFF)
      plot_ind = 1
    }
    if(plot_ind==1&model_ind[i]==1){
      lines(N[b1:b2],(MEAN_TIME[i,b1:b2]),type="l",col=COLOURS[i],lty=plot_LTY[i],lwd=LWD)
    }
  }
  
  
  
  
  #plot(c(0,0),main=leg_title,xlab=" ",ylab=" ",cex=0.00001,yaxt="n",xaxt="n")
  legend("topleft",legend=leg_names,col=leg_colours,lty=leg_lty,lwd=LWD,cex=0.9)
  
}

if(PLOT_PREDICTIONS==1){
  par(mfrow=c(1,1))
  plot_ind = 0
  ylab="P.A."
  if(LOGSCALE==1){
    MEAN_PRED=log(MEAN_PRED)
    ylab="log(P.A.)"
  }
  lim=c(as.vector(MEAN_PRED[model_ind==1,b1:b2]))
  lim = lim[!is.infinite(lim)]
  lim = lim[!is.nan(lim)]
  lim = lim[!is.na(lim)]
  for(i in 1:(length(model_ind))){
    if(plot_ind==0&model_ind[i]==1){
      main2=paste("Average P.A. (%), #Var =",num_var)
      if(LOGSCALE==1){
        main2=paste("Average log(P.A.) (%), #Var =",num_var)
      }
      main2=NULL
      plot(N[b1:b2],MEAN_PRED[i,b1:b2],type="l",col=COLOURS[i],lty=plot_LTY[i],
           ylim=c(min(lim),max(lim)),main=main2,xlab="N",lwd=LWD,
           ylab=ylab,cex.lab=CEXBUFF,cex.axis=CEXBUFF)
      plot_ind = 1
    }
    if(plot_ind==1&model_ind[i]==1){
      lines(N[b1:b2],(MEAN_PRED[i,b1:b2]),type="l",col=COLOURS[i],lty=plot_LTY[i],lwd=LWD)
    }
  }
}

legend("bottomright",title=leg_title,col=leg_colours,legend=leg_names,
       lty=leg_lty,lwd=LWD,cex=0.9)
print("  ")
print(paste("# rep =",Mrep+1))



